"""
Turn the raw per-seed results (results/raw/*.json) into every table, figure and
in-text number of the manuscript.

    python analyze.py [results_dir]

Outputs
  results/tables/table2_pima_features.csv      Table 2
  results/tables/table3_brfss_features.csv     Table 3
  results/tables/table4_partitions_seed0.csv   Table 4 (+ BRFSS partitions of Fig. 10)
  results/tables/table6_pima_results.csv       Table 6 (mean, SD, 95% CI)
  results/tables/table7_pima_overhead.csv      Table 7
  results/tables/table8_num_clients.csv        Table 8
  results/tables/table9_brfss_results.csv      Table 9
  results/tables/table10_lr_vs_mlp.csv         Table 10
  results/tables/table_paired_tests.csv        Wilcoxon tests used in the text
  results/tables/table_per_client.csv          per-client results (Section 6.4)
  results/tables/table_overhead_all.csv        HE overhead of every setting
  results/tables/manuscript_numbers.csv        every other number quoted in the text
  results/figures/fig3 ... fig12 (.png, 300 dpi)
"""
import glob
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines
import numpy as np
import pandas as pd
from scipy import stats

RES = sys.argv[1] if len(sys.argv) > 1 else "results"
RAW = os.path.join(RES, "raw")
FIG = os.path.join(RES, "figures")
TAB = os.path.join(RES, "tables")
os.makedirs(FIG, exist_ok=True)
os.makedirs(TAB, exist_ok=True)
PIMA_CSV = os.environ.get("PIMA_CSV", "data/diabetes.csv")
BRFSS_CSV = os.environ.get("BRFSS_CSV", "data/brfss.csv")

# ------------------------------------------------------------------ style
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({"font.size": 10, "axes.titlesize": 10.5, "axes.labelsize": 10,
                     "xtick.labelsize": 9.5, "ytick.labelsize": 9.5, "legend.fontsize": 9.5,
                     "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
                     "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.8, "axes.spines.top": False,
                     "axes.spines.right": False, "lines.linewidth": 1.8, "savefig.dpi": 300,
                     "font.family": "DejaVu Sans", "axes.axisbelow": True})
PW = 7.2   # figures drawn at print width (7.2 in -> printed at 6.5 in), so fonts print at >= 8 pt

LABEL = {"centralized_sgd": "Centralized (SGD)", "centralized_sklearn": "Centralized (L-BFGS, unpenalized)",
         "local_only": "Local-only (client mean)", "fedavg_plain": "FedAvg, plaintext",
         "fedavg_ckks": "FedAvg + CKKS (proposed)", "fedprox_ckks": "FedProx + CKKS (μ = 0.01)",
         "fedavg_ckks_unweighted": "FedAvg + CKKS, unweighted",
         "fedavg_ckks_classweight": "FedAvg + CKKS, class-weighted",
         "fedavg_ckks_no_global_update": "Original update rule (no global update, unweighted)"}
METRICS = ["acc", "prec", "rec", "f1", "auc"]
MNAME = {"acc": "Accuracy", "prec": "Precision", "rec": "Recall", "f1": "F1-score", "auc": "AUC", "loss": "Test loss"}
PARTS = {"iid": "IID", "dirichlet": "Non-IID (α = 0.5)", "age": "Age-based"}
AGE_LABELS = ["18–39", "40–54", "55–69", "70+"]

NUM = []   # (section, quantity, value)


def note(section, quantity, value):
    NUM.append(dict(section=section, quantity=quantity, value=value))


def load(ds, model, part, K):
    p = os.path.join(RAW, f"raw_{ds}_{model}_{part}_K{K}.json")
    return json.load(open(p)) if os.path.exists(p) else None


def vec(raw, m, k):
    return np.array([r["final"][m][k] for r in raw["runs"]], float)


def ci95(x):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    m, s = x.mean(), x.std(ddof=1)
    h = stats.t.ppf(0.975, len(x) - 1) * s / np.sqrt(len(x))
    return m, s, m - h, m + h


def wil(a, b):
    a, b = np.asarray(a), np.asarray(b)
    return 1.0 if np.allclose(a - b, 0) else float(stats.wilcoxon(a, b, zero_method="zsplit").pvalue)


def summarise(raw, ds, model, part):
    rows = []
    for meth in raw["methods"]:
        if meth not in raw["runs"][0]["final"]:
            continue
        rec = dict(dataset=ds, model=model, partition=PARTS[part], method=meth, label=LABEL[meth])
        for m in METRICS + ["loss"]:
            mu, sd, lo, hi = ci95(vec(raw, meth, m))
            rec.update({f"{m}_mean": mu, f"{m}_sd": sd, f"{m}_ci_lo": lo, f"{m}_ci_hi": hi})
        rows.append(rec)
    return rows


def pretty(df):
    out = df[["dataset", "model", "partition", "label"]].copy()
    for m in METRICS:
        if m == "auc":
            out["AUC"] = [f"{a:.3f} ± {b:.3f}" for a, b in zip(df["auc_mean"], df["auc_sd"])]
            out["AUC 95% CI"] = [f"[{a:.3f}, {b:.3f}]" for a, b in zip(df["auc_ci_lo"], df["auc_ci_hi"])]
        else:
            out[MNAME[m] + " (%)"] = [f"{100*a:.2f} ± {100*b:.2f}" for a, b in zip(df[f"{m}_mean"], df[f"{m}_sd"])]
            out[MNAME[m] + " 95% CI"] = [f"[{100*a:.2f}, {100*b:.2f}]" for a, b in zip(df[f"{m}_ci_lo"], df[f"{m}_ci_hi"])]
    return out


def timing(raw, meth="fedavg_ckks"):
    return [r["timing"][meth] for r in raw["runs"]]


# =================================================================== load
P = {(m, p, K): load("pima", m, p, K) for m in ["lr", "mlp"] for p in ["iid", "dirichlet"] for K in [4, 8, 16]}
B = {(m, p, K): load("brfss", m, p, K) for m in ["lr", "mlp"] for p in ["iid", "dirichlet", "age"] for K in [4, 16, 64]}
P = {k: v for k, v in P.items() if v}
B = {k: v for k, v in B.items() if v}
print("loaded Pima:", sorted(P), "\nloaded BRFSS:", sorted(B))
piid, pnon = P[("lr", "iid", 4)], P[("lr", "dirichlet", 4)]

# =================================================================== Table 2 (Pima features)
ZM = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
df = pd.read_csv(PIMA_CSV)
rows = []
for c in df.columns[:-1]:
    v = df[[c, "Outcome"]]
    if c in ZM:
        v = v[v[c] != 0]
    a, b = v[v.Outcome == 0][c], v[v.Outcome == 1][c]
    z = int((df[c] == 0).sum())
    rows.append(dict(feature=c, zeros=z, zeros_pct=100 * z / len(df), treated_as_missing=c in ZM,
                     median_nonzero=df.loc[df[c] != 0, c].median() if c in ZM else np.nan,
                     mean_outcome0=a.mean(), mean_outcome1=b.mean(), mannwhitney_p=stats.mannwhitneyu(a, b).pvalue))
pd.DataFrame(rows).to_csv(os.path.join(TAB, "table2_pima_features.csv"), index=False)
note("5.1.1", "Pima records / diabetic", f"{len(df)} / {int(df.Outcome.sum())}")

# =================================================================== Table 3 (BRFSS features)
if os.path.exists(BRFSS_CSV):
    bd = pd.read_csv(BRFSS_CSV)
    y = bd.pop("Diabetes_binary")
    rows = []
    for c in bd.columns:
        lv = bd[c].nunique()
        typ = "binary" if lv == 2 else ("ordinal" if c in ["GenHlth", "Age", "Education", "Income"] else "count/continuous")
        rows.append(dict(feature=c, type=f"{typ} ({lv} levels)", mean_no_diabetes=bd[c][y == 0].mean(),
                         mean_diabetes=bd[c][y == 1].mean(), mannwhitney_p=stats.mannwhitneyu(bd[c][y == 0], bd[c][y == 1]).pvalue))
    pd.DataFrame(rows).to_csv(os.path.join(TAB, "table3_brfss_features.csv"), index=False)
    note("5.1.2", "BRFSS records / positives / prevalence %", f"{len(y)} / {int(y.sum())} / {100*y.mean():.1f}")
    dup = int(pd.concat([bd, y], axis=1).duplicated().sum())
    note("5.1.2", "BRFSS exact duplicate records (n, %)", f"{dup} ({100*dup/len(y):.1f}%)")
    note("5.1.2", "BRFSS max Mann-Whitney p over features", f"{max(r['mannwhitney_p'] for r in rows):.1e}")

# =================================================================== Table 4 (+ BRFSS partitions)
rows = []
for (ds, raw, pn) in [("Pima", piid, "IID"), ("Pima", pnon, "Non-IID (α = 0.5)")] + \
        [("BRFSS", B[("lr", p, 4)], PARTS[p]) for p in ["iid", "dirichlet", "age"] if ("lr", p, 4) in B]:
    for p in raw["runs"][0]["partition"]:
        tot = p["n_train"] + p["n_test"]
        pos = p["n_train_pos"] + p["n_test_pos"]
        rows.append(dict(dataset=ds, partition=pn, client=p["client"], train=p["n_train"], train_pos=p["n_train_pos"],
                         local_test=p["n_test"], local_test_pos=p["n_test_pos"], total=tot, diabetic_share_pct=100 * pos / tot))
part_tab = pd.DataFrame(rows)
part_tab.to_csv(os.path.join(TAB, "table4_partitions_seed0.csv"), index=False)
note("5.2", "Pima global test set n / positives", f"{piid['runs'][0]['n_global_test']} / {piid['runs'][0]['n_global_test_pos']}")
if ("lr", "iid", 4) in B:
    r0 = B[("lr", "iid", 4)]["runs"][0]
    note("5.2", "BRFSS global test set n / positives", f"{r0['n_global_test']} / {r0['n_global_test_pos']}")

# =================================================================== Table 6 (Pima LR)
main = pd.DataFrame(summarise(piid, "Pima", "LR", "iid") + summarise(pnon, "Pima", "LR", "dirichlet"))
main.to_csv(os.path.join(TAB, "table6_pima_results.csv"), index=False)
pretty(main).to_csv(os.path.join(TAB, "table6_pima_results_pretty.csv"), index=False)

# =================================================================== paired tests
tests = []


def add_test(ds, model, part, A, Bm, rawA, rawB=None, metrics_=("acc", "f1", "auc")):
    rawB = rawB or rawA
    for m in metrics_:
        a, b = vec(rawA, A, m), vec(rawB, Bm, m)
        tests.append(dict(dataset=ds, model=model, partition=PARTS[part], A=A, B=Bm, metric=m,
                          mean_A=a.mean(), mean_B=b.mean(), mean_diff=(a - b).mean(),
                          max_abs_diff=np.abs(a - b).max(), wilcoxon_p=wil(a, b)))


for part, raw in [("iid", piid), ("dirichlet", pnon)]:
    for other in ["fedavg_plain", "centralized_sgd", "local_only"]:
        add_test("Pima", "LR", part, "fedavg_ckks", other, raw)
for (m, p, K), raw in B.items():
    if K == 4:
        for other in ["fedavg_plain", "centralized_sgd", "local_only"]:
            add_test("BRFSS", m.upper(), p, "fedavg_ckks", other, raw)
for p in ["iid", "dirichlet"]:
    if ("mlp", p, 4) in P:
        for other in ["fedavg_plain", "centralized_sgd", "local_only"]:
            add_test("Pima", "MLP", p, "fedavg_ckks", other, P[("mlp", p, 4)])
        tests.append(dict(dataset="Pima", model="MLP vs LR", partition=PARTS[p], A="fedavg_ckks (MLP)", B="fedavg_ckks (LR)",
                          metric="auc", mean_A=vec(P[("mlp", p, 4)], "fedavg_ckks", "auc").mean(),
                          mean_B=vec(P[("lr", p, 4)], "fedavg_ckks", "auc").mean(),
                          mean_diff=(vec(P[("mlp", p, 4)], "fedavg_ckks", "auc") - vec(P[("lr", p, 4)], "fedavg_ckks", "auc")).mean(),
                          max_abs_diff=np.nan,
                          wilcoxon_p=wil(vec(P[("mlp", p, 4)], "fedavg_ckks", "auc"), vec(P[("lr", p, 4)], "fedavg_ckks", "auc"))))
for p in ["iid", "dirichlet", "age"]:
    if ("mlp", p, 4) in B and ("lr", p, 4) in B:
        a, b = vec(B[("mlp", p, 4)], "fedavg_ckks", "auc"), vec(B[("lr", p, 4)], "fedavg_ckks", "auc")
        tests.append(dict(dataset="BRFSS", model="MLP vs LR", partition=PARTS[p], A="fedavg_ckks (MLP)", B="fedavg_ckks (LR)",
                          metric="auc", mean_A=a.mean(), mean_B=b.mean(), mean_diff=(a - b).mean(),
                          max_abs_diff=np.abs(a - b).max(), wilcoxon_p=wil(a, b)))
TT = pd.DataFrame(tests)
TT.to_csv(os.path.join(TAB, "table_paired_tests.csv"), index=False)


def ptest(ds, model, part, B_, metric):
    r = TT[(TT.dataset == ds) & (TT.model == model) & (TT.partition == PARTS[part]) & (TT.B == B_) & (TT.metric == metric)]
    return float(r.wilcoxon_p.iloc[0])


# =================================================================== Pima text numbers (Sections 6.1-6.5)
def round_mean(raw, meth, getter):
    return np.array([[getter(h) for h in r["rounds"][meth]] for r in raw["runs"]]).mean(0)


tl = round_mean(piid, "fedavg_ckks", lambda h: h["train_loss"])
r10 = min(9, len(tl) - 1)   # round 10 (or the last round in short smoke tests)
tn = round_mean(pnon, "fedavg_ckks", lambda h: h["train_loss"])
note("6.1", "IID training loss after rounds 1 / 10 / 20", f"{tl[0]:.3f} / {tl[r10]:.3f} / {tl[-1]:.3f}")
note("6.1", "IID reduction over last ten rounds (%)", f"{100*(tl[r10]-tl[-1])/tl[r10]:.1f}")
note("6.1", "Non-IID training loss after rounds 1 / 20", f"{tn[0]:.3f} / {tn[-1]:.3f}")
note("6.1", "Accuracy gap corrected vs original update rule, IID (pp)",
     f"{100*(vec(piid,'fedavg_ckks','acc').mean()-vec(piid,'fedavg_ckks_no_global_update','acc').mean()):.2f}")
a1 = round_mean(piid, "fedavg_ckks", lambda h: h["global_test"]["acc"])
note("6.2", "IID accuracy after round 1 / round 20 (%)", f"{100*a1[0]:.2f} / {100*a1[-1]:.2f}")
for part, raw in [("iid", piid), ("dirichlet", pnon)]:
    note("6.3", f"Max final-parameter gap CKKS vs plaintext ({part})", f"{max(r['final_param_gap_ckks_vs_plain'] for r in raw['runs']):.1e}")
    note("6.3", f"Max changed test predictions CKKS vs plaintext ({part})", max(r["pred_changes_ckks_vs_plain"] for r in raw["runs"]))
m, s, lo, hi = ci95(vec(piid, "fedavg_ckks", "acc")); note("6.3", "IID FedAvg+CKKS accuracy mean ± SD [95% CI] (%)", f"{100*m:.2f} ± {100*s:.2f} [{100*lo:.2f}, {100*hi:.2f}]")
m, s, lo, hi = ci95(vec(piid, "fedavg_ckks", "auc")); note("6.3", "IID FedAvg+CKKS AUC mean ± SD [95% CI]", f"{m:.3f} ± {s:.3f} [{lo:.3f}, {hi:.3f}]")
note("6.3", "p, CKKS vs centralized, IID accuracy / AUC", f"{ptest('Pima','LR','iid','centralized_sgd','acc'):.3f} / {ptest('Pima','LR','iid','centralized_sgd','auc'):.3f}")
note("6.3", "p, CKKS vs centralized, non-IID accuracy", f"{ptest('Pima','LR','dirichlet','centralized_sgd','acc'):.3f}")
for part, raw in [("iid", piid), ("dirichlet", pnon)]:
    note("6.3", f"Gain over local-only, {part}: accuracy pp (p) / F1 pp (p)",
         f"{100*(vec(raw,'fedavg_ckks','acc')-vec(raw,'local_only','acc')).mean():.2f} ({ptest('Pima','LR',part,'local_only','acc'):.3f}) / "
         f"{100*(vec(raw,'fedavg_ckks','f1')-vec(raw,'local_only','f1')).mean():.2f} ({ptest('Pima','LR',part,'local_only','f1'):.3f})")
for part, raw in [("iid", piid), ("dirichlet", pnon)]:
    d = [100 * abs(vec(raw, "fedprox_ckks", k).mean() - vec(raw, "fedavg_ckks", k).mean()) for k in ["acc", "f1"]]
    note("6.3", f"|FedProx - FedAvg| accuracy / F1, {part} (pp)", f"{d[0]:.2f} / {d[1]:.2f}")

# per-client (Section 6.4, Fig. 7)
pc = []
for part, raw in [("iid", piid), ("dirichlet", pnon)]:
    K = len(raw["runs"][0]["partition"])
    for k in range(K):
        rec = dict(partition=PARTS[part], client=k + 1)
        for m in METRICS:
            v = [r["per_client_final"]["fedavg_ckks"][k][m] for r in raw["runs"]]
            lo_ = [r["local_only_per_client"][k]["local_test"][m] for r in raw["runs"]]
            rec[f"{m}_mean"], rec[f"{m}_sd"] = np.nanmean(v), np.nanstd(v, ddof=1)
            rec[f"local_only_{m}_mean"] = np.nanmean(lo_)
        rec["n_test"] = np.mean([r["partition"][k]["n_test"] for r in raw["runs"]])
        pc.append(rec)
pcd = pd.DataFrame(pc)
pcd.to_csv(os.path.join(TAB, "table_per_client.csv"), index=False)
d = pcd[pcd.partition == "IID"]
note("6.4", "IID per-client accuracy range (%) / AUC range", f"{100*d.acc_mean.min():.2f}–{100*d.acc_mean.max():.2f} / {d.auc_mean.min():.3f}–{d.auc_mean.max():.3f}")
note("6.4", "IID client 1 accuracy mean ± SD (%)", f"{100*d.acc_mean.iloc[0]:.2f} ± {100*d.acc_sd.iloc[0]:.2f}")
roc = piid["runs"][0]["roc"]
note("6.4", "Seed 0 ROC: global AUC [CI]", f"{roc['global']['auc']:.3f} [{roc['global']['auc_ci'][0]:.3f}, {roc['global']['auc_ci'][1]:.3f}]")
note("6.4", "Seed 0 ROC: clients AUC [CI]", "; ".join(f"{c['auc']:.3f} [{c['auc_ci'][0]:.3f}, {c['auc_ci'][1]:.3f}]" for c in roc["clients"]))
cm = piid["runs"][0]["confusion_global_fedavg_ckks"]
note("6.4", "Seed 0 confusion matrix TN/FP/FN/TP", f"{cm[0][0]}/{cm[0][1]}/{cm[1][0]}/{cm[1][1]}")
for part, raw in [("iid", piid), ("dirichlet", pnon)]:
    dd = {k: 100 * (vec(raw, "fedavg_ckks_classweight", k).mean() - vec(raw, "fedavg_ckks", k).mean()) for k in ["acc", "prec", "rec", "f1"]}
    note("6.5", f"Class weighting effect, {part}: Δrecall / ΔF1 / Δprecision / Δaccuracy (pp)",
         f"{dd['rec']:+.2f} / {dd['f1']:+.2f} / {dd['prec']:+.2f} / {dd['acc']:+.2f}")

# =================================================================== overhead (all settings)
ov = []
for (ds, D) in [("pima", P), ("brfss", B)]:
    for (model, part, K), raw in D.items():
        if "fedavg_ckks" not in raw.get("runs", [{}])[0].get("timing", {}):
            continue
        t = timing(raw)
        R = raw["config"]["rounds"]
        row = dict(dataset=ds, model=model, partition=part, K=K, n_params=raw["runs"][0]["n_params"],
                   enc_ms_per_client=1e3 * np.mean([x["enc_s"] for x in t]),
                   agg_ms_server=1e3 * np.mean([x["agg_s"] for x in t]),
                   dec_ms_per_client=1e3 * np.mean([x["dec_s"] for x in t]),
                   ct_kb_per_client=np.mean([x["ct_bytes"] for x in t]) / 1024,
                   agg_ct_kb=np.mean([x["agg_ct_bytes"] for x in t]) / 1024,
                   plain_bytes_per_client=raw["runs"][0]["plain_payload_bytes"],
                   public_ctx_mb=raw["runs"][0]["ckks"]["public_ctx_bytes"] / 2**20,
                   keygen_ms=1e3 * np.mean([r["ckks"]["keygen_s"] for r in raw["runs"]]),
                   approx_err_mean=np.mean([x["approx_err"] for x in t]),
                   approx_err_max=np.max([x["approx_err_max"] for x in t]),
                   approx_err_median_of_run_max=np.median([x["approx_err_max"] for x in t]),
                   final_param_gap_max=np.max([r["final_param_gap_ckks_vs_plain"] for r in raw["runs"]]),
                   auc_gap_max=np.max([r["auc_gap_ckks_vs_plain"] for r in raw["runs"]]),
                   pred_changes_max=np.max([r["pred_changes_ckks_vs_plain"] for r in raw["runs"]]),
                   prep_err_max=np.max([r["prep_ckks_abs_err"] for r in raw["runs"]]),
                   mean_client_train=np.mean([np.mean([p["n_train"] for p in r["partition"]]) for r in raw["runs"]]),
                   min_client_train=np.min([np.min([p["n_train"] for p in r["partition"]]) for r in raw["runs"]]))
        row["he_ms_per_round"] = row["enc_ms_per_client"] + row["agg_ms_server"] + row["dec_ms_per_client"]
        row["uplink_mb_per_round"] = row["ct_kb_per_client"] * K / 1024
        row["downlink_mb_per_round"] = row["agg_ct_kb"] * K / 1024
        row["traffic_mb_total"] = (row["uplink_mb_per_round"] + row["downlink_mb_per_round"]) * R
        row["expansion_factor"] = row["ct_kb_per_client"] * 1024 / row["plain_bytes_per_client"]
        for m in ["acc", "auc"]:
            for meth in ["fedavg_ckks", "local_only", "centralized_sgd", "fedavg_plain"]:
                if meth in raw["runs"][0]["final"]:
                    row[f"{meth}_{m}_mean"] = vec(raw, meth, m).mean()
                    row[f"{meth}_{m}_sd"] = vec(raw, meth, m).std(ddof=1)
        ov.append(row)
ov = pd.DataFrame(ov).sort_values(["dataset", "model", "partition", "K"])
ov.to_csv(os.path.join(TAB, "table_overhead_all.csv"), index=False)


def ovrow(ds, model, part, K):
    return ov[(ov.dataset == ds) & (ov.model == model) & (ov.partition == part) & (ov.K == K)].iloc[0]


# Table 7
o = ovrow("pima", "lr", "iid", 4)
t7 = [("Encryption time per client (ms)", f"{o.enc_ms_per_client:.2f}"),
      ("Server aggregation time, 4 ciphertexts weighted (ms)", f"{o.agg_ms_server:.2f}"),
      ("Decryption time per client (ms)", f"{o.dec_ms_per_client:.2f}"),
      ("HE time on critical path per round (ms)", f"{o.he_ms_per_round:.2f}"),
      ("Key generation, once (ms)", f"{o.keygen_ms:.1f}"),
      ("Public context size, once (MB)", f"{o.public_ctx_mb:.2f}"),
      ("Ciphertext size per client, uplink (KB)", f"{o.ct_kb_per_client:.1f}"),
      ("Aggregated ciphertext size, downlink (KB)", f"{o.agg_ct_kb:.1f}"),
      ("Parameter vector size per client, plaintext (bytes)", f"{int(o.plain_bytes_per_client)}"),
      ("Uplink volume per round, all clients (MB)", f"{o.uplink_mb_per_round:.2f}"),
      ("Total traffic, 20 rounds, uplink + downlink (MB)", f"{o.traffic_mb_total:.1f}"),
      ("Mean / max approximation error of aggregate", f"{o.approx_err_mean:.1e} / {o.approx_err_max:.1e}"),
      ("Max final-parameter gap, CKKS vs plaintext", f"{o.final_param_gap_max:.1e}"),
      ("Ciphertext expansion factor", f"{o.expansion_factor:.0f}"),
      ("Max preprocessing deviation, CKKS vs plaintext", f"{o.prep_err_max:.1e}")]
pd.DataFrame(t7, columns=["quantity", "value"]).to_csv(os.path.join(TAB, "table7_pima_overhead.csv"), index=False)
for q, v in t7:
    note("6.6 / Table 7", q, v)

# Table 8
t8 = []
for ds, model, part, K in [("pima", "lr", "iid", 4), ("pima", "lr", "iid", 8), ("pima", "lr", "iid", 16),
                           ("pima", "lr", "dirichlet", 4), ("pima", "lr", "dirichlet", 8), ("pima", "lr", "dirichlet", 16),
                           ("brfss", "lr", "iid", 4), ("brfss", "lr", "iid", 16), ("brfss", "lr", "iid", 64)]:
    try:
        o = ovrow(ds, model, part, K)
    except IndexError:
        continue
    t8.append({"Dataset, partition": f"{'Pima' if ds == 'pima' else 'BRFSS'}, {'IID' if part == 'iid' else 'non-IID'}", "K": K,
               "Mean train records per client": round(o.mean_client_train, 1),
               "Accuracy (%)": f"{100*o.fedavg_ckks_acc_mean:.2f} ± {100*o.fedavg_ckks_acc_sd:.2f}",
               "AUC": f"{o.fedavg_ckks_auc_mean:.3f} ± {o.fedavg_ckks_auc_sd:.3f}",
               "Local-only accuracy (%)": f"{100*o.local_only_acc_mean:.2f} ± {100*o.local_only_acc_sd:.2f}",
               "Local-only AUC": f"{o.local_only_auc_mean:.3f} ± {o.local_only_auc_sd:.3f}",
               "Server aggregation (ms)": round(o.agg_ms_server, 2),
               "Uplink per round (MB)": round(o.uplink_mb_per_round, 2),
               "Gain over local-only (pp accuracy)": round(100 * (o.fedavg_ckks_acc_mean - o.local_only_acc_mean), 2)})
pd.DataFrame(t8).to_csv(os.path.join(TAB, "table8_num_clients.csv"), index=False)

# =================================================================== BRFSS (Table 9, Section 6.8)
if B:
    b9 = []
    order_lr = ["centralized_sgd", "centralized_sklearn", "local_only", "fedavg_plain", "fedavg_ckks", "fedprox_ckks", "fedavg_ckks_classweight"]
    order_mlp = ["centralized_sgd", "local_only", "fedavg_plain", "fedavg_ckks", "fedavg_ckks_classweight"]
    for part in ["iid", "dirichlet", "age"]:
        for model, order in [("lr", order_lr), ("mlp", order_mlp)]:
            raw = B.get((model, part, 4))
            if raw:
                s = pd.DataFrame(summarise(raw, "BRFSS", model.upper(), part)).set_index("method")
                b9 += s.loc[[m for m in order if m in s.index]].reset_index().to_dict("records")
    b9 = pd.DataFrame(b9)
    b9.to_csv(os.path.join(TAB, "table9_brfss_results.csv"), index=False)
    pretty(b9).to_csv(os.path.join(TAB, "table9_brfss_results_pretty.csv"), index=False)

    lr = {p: B.get(("lr", p, 4)) for p in ["iid", "dirichlet", "age"]}
    mlp = {p: B.get(("mlp", p, 4)) for p in ["iid", "dirichlet", "age"]}
    for p in ["iid", "age"]:
        if lr[p]:
            note("6.8", f"BRFSS LR max final-parameter gap CKKS vs plaintext ({p})", f"{max(r['final_param_gap_ckks_vs_plain'] for r in lr[p]['runs']):.1e}")
    lr_all = [r for (m, p, K), raw in B.items() if m == "lr" for r in raw["runs"] if "auc_gap_ckks_vs_plain" in r]
    note("6.8", "BRFSS LR, all settings: max |AUC CKKS - plaintext|", f"{max(r['auc_gap_ckks_vs_plain'] for r in lr_all):.1e}")
    note("6.8", "BRFSS LR, all settings: max changed test predictions", max(r["pred_changes_ckks_vs_plain"] for r in lr_all))
    for p in ["iid", "dirichlet", "age"]:
        if lr[p]:
            f, c = vec(lr[p], "fedavg_ckks", "auc"), vec(lr[p], "centralized_sgd", "auc")
            note("6.8", f"BRFSS LR {p}: AUC CKKS vs centralized (mean ± SD), diff, p",
                 f"{f.mean():.3f} ± {f.std(ddof=1):.3f} vs {c.mean():.3f} ± {c.std(ddof=1):.3f}, {c.mean()-f.mean():.4f}, p = {wil(f, c):.3f}")
            l = vec(lr[p], "local_only", "auc")
            note("6.8", f"BRFSS LR {p}: AUC CKKS vs local-only, gain, p",
                 f"{f.mean():.3f} ± {f.std(ddof=1):.3f} vs {l.mean():.3f} ± {l.std(ddof=1):.3f}, {f.mean()-l.mean():.3f}, p = {wil(f, l):.3f}")
    if lr["dirichlet"]:
        note("6.8", "BRFSS Dirichlet: smallest client training split over all seeds",
             int(min(p["n_train"] for r in lr["dirichlet"]["runs"] for p in r["partition"])))
        P0 = lr["dirichlet"]["runs"][0]["partition"]
        prev = [100 * (p["n_train_pos"] + p["n_test_pos"]) / (p["n_train"] + p["n_test"]) for p in P0]
        note("6.8", "BRFSS Dirichlet seed 0 client prevalence range (%)", f"{min(prev):.1f}–{max(prev):.1f}")
    if lr["age"]:
        P0 = lr["age"]["runs"][0]["partition"]
        note("6.8", "BRFSS age-based seed 0 prevalence 18-39 / 40-54 / 55-69 / 70+ (%)",
             " / ".join(f"{100*(p['n_train_pos']+p['n_test_pos'])/(p['n_train']+p['n_test']):.1f}" for p in P0))
        note("6.8", "BRFSS age-based: youngest-group local model AUC on global test",
             f"{np.mean([r['local_only_per_client'][0]['global_test']['auc'] for r in lr['age']['runs']]):.3f}")
    if lr["iid"]:
        P0 = lr["iid"]["runs"][0]["partition"]
        note("6.8", "BRFSS IID seed 0 records per client (train+local test)", ", ".join(str(p["n_train"] + p["n_test"]) for p in P0))
    if mlp["age"]:
        note("6.8", "BRFSS age-based MLP: AUC gain of FedAvg+CKKS over local-only",
             f"{(vec(mlp['age'],'fedavg_ckks','auc')-vec(mlp['age'],'local_only','auc')).mean():.3f}")
    for p in ["iid", "dirichlet", "age"]:
        if lr[p]:
            for meth in ["fedavg_ckks", "local_only", "centralized_sgd", "fedprox_ckks", "fedavg_ckks_classweight"]:
                note("6.8", f"BRFSS LR {p} {meth}: recall / F1 / acc / prec (%) / AUC",
                     " / ".join(f"{100*vec(lr[p],meth,k).mean():.2f} ± {100*vec(lr[p],meth,k).std(ddof=1):.2f}" for k in ["rec", "f1", "acc", "prec"])
                     + f" / {vec(lr[p],meth,'auc').mean():.3f} ± {vec(lr[p],meth,'auc').std(ddof=1):.3f}")
    # convergence (Fig. 12)
    for p in ["iid", "dirichlet", "age"]:
        if lr[p]:
            cur = round_mean(lr[p], "fedavg_ckks", lambda h: h["global_test"]["auc"])
            note("6.8", f"BRFSS LR {p}: AUC after round 1 / max |round mean - final|", f"{cur[0]:.3f} / {np.max(np.abs(cur - cur[-1])):.4f}")
    if lr["iid"]:
        note("6.8", "AUC SD ratio Pima / BRFSS (IID, FedAvg+CKKS)",
             f"{vec(piid,'fedavg_ckks','auc').std(ddof=1)/vec(lr['iid'],'fedavg_ckks','auc').std(ddof=1):.1f}")
    # K = 16 / 64 local-only
    for K in [4, 16, 64]:
        if ("lr", "iid", K) in B:
            o = ovrow("brfss", "lr", "iid", K)
            note("6.7", f"BRFSS IID K={K}: CKKS AUC / local-only AUC / agg ms / uplink MB",
                 f"{o.fedavg_ckks_auc_mean:.3f} ± {o.fedavg_ckks_auc_sd:.3f} / {o.local_only_auc_mean:.3f} / {o.agg_ms_server:.2f} / {o.uplink_mb_per_round:.2f}")

    # MLP section 6.9
    for p in ["iid", "dirichlet", "age"]:
        if mlp[p] and lr[p]:
            a, b = vec(mlp[p], "fedavg_ckks", "auc"), vec(lr[p], "fedavg_ckks", "auc")
            note("6.9", f"BRFSS {p}: MLP - LR AUC (FedAvg+CKKS), p; MLP AUC", f"{a.mean()-b.mean():.3f}, p = {wil(a, b):.3f}; {a.mean():.3f} ± {a.std(ddof=1):.3f}")
            c = vec(mlp[p], "centralized_sgd", "auc")
            note("6.9", f"BRFSS {p}: MLP centralized - federated AUC, p", f"{c.mean()-a.mean():.3f}, p = {wil(a, c):.3f}")
    if ("mlp", "iid", 4) in P:
        a, b = vec(P[("mlp", "iid", 4)], "fedavg_ckks", "auc"), vec(piid, "fedavg_ckks", "auc")
        note("6.9", "Pima IID: MLP vs LR AUC (FedAvg+CKKS), p", f"{a.mean():.3f} ± {a.std(ddof=1):.3f} vs {b.mean():.3f} ± {b.std(ddof=1):.3f}, p = {wil(a, b):.3f}")
    mlp_rows = ov[ov.model == "mlp"]
    lr_rows = ov[ov.model == "lr"]
    note("6.9", "Median of per-run maximum approximation errors, MLP / LR (all settings)",
         f"{np.median([x['approx_err_max'] for (m,p,K),raw in list(P.items())+list(B.items()) if m=='mlp' for x in timing(raw)]):.1e} / "
         f"{np.median([x['approx_err_max'] for (m,p,K),raw in list(P.items())+list(B.items()) if m=='lr' for x in timing(raw)]):.1e}")
    note("6.9", "Largest per-round approximation error, LR / MLP (all settings, FedAvg+CKKS)",
         f"{lr_rows.approx_err_max.max():.1e} / {mlp_rows.approx_err_max.max():.1e}")
    allenc = []
    for (m, p, K), raw in list(P.items()) + list(B.items()):
        for meth, t in raw["runs"][0].get("timing", {}).items():
            allenc.append((m, p, K, meth, max(r["timing"][meth]["approx_err_max"] for r in raw["runs"])))
    worst = max(allenc, key=lambda x: x[4])
    note("6.9", "Largest per-round approximation error over every encrypted variant (model, partition, K, method, value)",
         f"{worst[0]}, {worst[1]}, K={worst[2]}, {worst[3]}, {worst[4]:.1e}")
    note("6.9", "Max final-parameter gap MLP, BRFSS / Pima",
         f"{mlp_rows[mlp_rows.dataset=='brfss'].final_param_gap_max.max():.1e} / {mlp_rows[mlp_rows.dataset=='pima'].final_param_gap_max.max():.1e}")
    note("6.9", "Max |AUC CKKS - plaintext| MLP (all datasets/partitions)", f"{mlp_rows.auc_gap_max.max():.1e}")
    note("6.9", "Max changed test predictions MLP (all)", int(mlp_rows.pred_changes_max.max()))
    # within-X-of-centralized claim
    gaps = []
    for (m, p, K), raw in list(P.items()) + list(B.items()):
        if K == 4 and "centralized_sgd" in raw["runs"][0]["final"]:
            gaps.append((m, p, vec(raw, "centralized_sgd", "auc").mean() - vec(raw, "fedavg_ckks", "auc").mean()))
    g = max(gaps, key=lambda x: x[2])
    note("7", "Largest (centralized - FedAvg+CKKS) AUC over datasets, models, partitions (K=4)", f"{g[2]:.4f} ({g[0]}, {g[1]})")
    he4 = ov[ov.K == 4][["dataset", "model", "partition", "he_ms_per_round"]]
    note("Abstract", "HE ms per round, K=4, range over all settings", f"{he4.he_ms_per_round.min():.1f}–{he4.he_ms_per_round.max():.1f}")

# Table 10
t10 = []
for ds, D, raw_lr_key in [("Pima", P, None), ("BRFSS", B, None)]:
    for model in ["lr", "mlp"]:
        raw = D.get((model, "iid", 4))
        if not raw:
            continue
        o = ovrow(ds.lower(), model, "iid", 4)
        t10.append(dict(Data=ds, Model=model.upper(), Params=int(o.n_params), Slots=f"{100*o.n_params/4096:.2f}%",
                        CT_KB=round(o.ct_kb_per_client, 1), HE_ms=round(o.he_ms_per_round, 2),
                        Max_error=f"{o.approx_err_max:.1e}", Max_gap=f"{o.final_param_gap_max:.1e}",
                        AUC_CKKS=round(vec(raw, "fedavg_ckks", "auc").mean(), 3), AUC_plain=round(vec(raw, "fedavg_plain", "auc").mean(), 3),
                        AUC_central=round(vec(raw, "centralized_sgd", "auc").mean(), 3), AUC_local=round(vec(raw, "local_only", "auc").mean(), 3),
                        expansion=round(o.expansion_factor, 0)))
pd.DataFrame(t10).to_csv(os.path.join(TAB, "table10_lr_vs_mlp.csv"), index=False)

# Section 6.7 numbers (Pima)
for part in ["iid", "dirichlet"]:
    s = []
    for K in [4, 8, 16]:
        if ("lr", part, K) in P:
            o = ovrow("pima", "lr", part, K)
            s.append(f"K={K}: {100*o.fedavg_ckks_acc_mean:.2f} ± {100*o.fedavg_ckks_acc_sd:.2f} vs local {100*o.local_only_acc_mean:.2f} ± {100*o.local_only_acc_sd:.2f} (gain {100*(o.fedavg_ckks_acc_mean-o.local_only_acc_mean):.2f})")
    note("6.7", f"Pima {part}: accuracy CKKS vs local-only by K", "; ".join(s))

pd.DataFrame(NUM).to_csv(os.path.join(TAB, "manuscript_numbers.csv"), index=False)

# =================================================================== figures
R = piid["config"]["rounds"]
x = np.arange(1, R + 1)


def series(raw, meth, getter):
    return np.array([[getter(h) for h in r["rounds"][meth]] for r in raw["runs"]])


def band(ax, raw, meth, getter, color, label, ls="-"):
    a = series(raw, meth, getter)
    m, s = np.nanmean(a, 0), np.nanstd(a, 0, ddof=1)
    ax.plot(x, m, color=color, label=label, ls=ls)
    ax.fill_between(x, m - s, m + s, color=color, alpha=0.15, lw=0)


def pct(v):
    return f"{v:.1f}%" if v < 1 else f"{v:.0f}%"


def partition_bars(ax, Pn, title, scale=1.0, labels=("Non-diabetic", "Diabetic"), show_total=True):
    k = np.arange(1, len(Pn) + 1)
    neg = np.array([p["n_train"] - p["n_train_pos"] + p["n_test"] - p["n_test_pos"] for p in Pn]) / scale
    pos = np.array([p["n_train_pos"] + p["n_test_pos"] for p in Pn]) / scale
    ax.bar(k, neg, color=C[0], width=0.62, label=labels[0], edgecolor="white", linewidth=1.5)
    ax.bar(k, pos, bottom=neg, color=C[1], width=0.62, label=labels[1], edgecolor="white", linewidth=1.5)
    for kk, n0, n1 in zip(k, neg, pos):
        tot = n0 + n1
        lab = f"{tot:.0f}\n{pct(100*n1/tot)}" if show_total else pct(100 * n1 / tot)
        ax.text(kk, tot + max(neg + pos) * 0.02, lab, ha="center", va="bottom", fontsize=9, color=INK)
    ax.set_xticks(k, [f"C{i}" for i in k])
    ax.set_title(title, loc="left")
    ax.grid(axis="x", visible=False)
    return max(neg + pos)


# Fig 3: Pima partitions (seed 0)
fig, axes = plt.subplots(1, 2, figsize=(PW, 3.3), sharey=True)
mx = max(partition_bars(axes[0], piid["runs"][0]["partition"], "(a) IID (stratified)"),
         partition_bars(axes[1], pnon["runs"][0]["partition"], "(b) Non-IID (Dirichlet α = 0.5)"))
for ax in axes:
    ax.set_xlabel("Client"); ax.set_ylim(0, mx * 1.32)
axes[0].set_ylabel("Records per client")
axes[0].legend(loc="upper left", frameon=False, ncol=2)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig3_pima_partitions.png")); plt.close(fig)

# Fig 4: loss curves
fig, axes = plt.subplots(1, 2, figsize=(PW, 3.9), sharey=True)
for ax, raw, title in [(axes[0], piid, "(a) IID"), (axes[1], pnon, "(b) Non-IID (α = 0.5)")]:
    band(ax, raw, "fedavg_ckks", lambda h: h["train_loss"], C[0], "FedAvg + CKKS, training loss")
    band(ax, raw, "fedavg_ckks", lambda h: h["global_test"]["loss"], C[1], "FedAvg + CKKS, test loss")
    band(ax, raw, "fedavg_plain", lambda h: h["global_test"]["loss"], INK2, "FedAvg plaintext, test loss", ls=":")
    band(ax, raw, "fedavg_ckks_no_global_update", lambda h: h["global_test"]["loss"], C[6],
         "Original update rule (no global update), test loss", ls="--")
    ax.set_title(title, loc="left"); ax.set_xlabel("Communication round"); ax.set_xticks([1, 5, 10, 15, 20])
axes[0].set_ylabel("Binary cross-entropy")
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=2, frameon=False)
fig.tight_layout(rect=(0, 0.16, 1, 1)); fig.savefig(os.path.join(FIG, "fig4_loss.png")); plt.close(fig)

# Fig 5: metrics per round
fig, axes = plt.subplots(2, 3, figsize=(PW, 5.2)); axes = axes.ravel()
for ax, m in zip(axes, METRICS):
    band(ax, piid, "fedavg_ckks", lambda h, m=m: h["global_test"][m], C[0], "FedAvg + CKKS, IID")
    band(ax, pnon, "fedavg_ckks", lambda h, m=m: h["global_test"][m], C[1], "FedAvg + CKKS, non-IID (α = 0.5)")
    ax.axhline(vec(piid, "centralized_sgd", m).mean(), color=INK2, ls=":", lw=1.5, label="Centralized LR (IID splits)")
    ax.set_title(MNAME[m], loc="left"); ax.set_xlabel("Round"); ax.set_xticks([1, 5, 10, 15, 20])
h, l = axes[0].get_legend_handles_labels()
axes[5].axis("off"); axes[5].legend(h, l, loc="center", frameon=False, fontsize=9.5)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig5_metrics_rounds.png")); plt.close(fig)

# Fig 6: baselines with 95% CI
show = ["centralized_sgd", "local_only", "fedavg_plain", "fedavg_ckks", "fedprox_ckks", "fedavg_ckks_classweight"]
fig, axes = plt.subplots(1, 3, figsize=(PW, 3.9), sharey=True)
for ax, m in zip(axes, ["acc", "f1", "auc"]):
    for i, (pname, col) in enumerate([("IID", C[0]), ("Non-IID (α = 0.5)", C[1])]):
        d = main[main.partition == pname].set_index("method").loc[show]
        yy = np.arange(len(show)) + (i - 0.5) * 0.36
        err = np.vstack([d[f"{m}_mean"] - d[f"{m}_ci_lo"], d[f"{m}_ci_hi"] - d[f"{m}_mean"]])
        ax.errorbar(d[f"{m}_mean"], yy, xerr=err, fmt="o", ms=6, color=col, ecolor=col, elinewidth=1.8, capsize=2.5, label=pname)
    ax.set_yticks(np.arange(len(show)), [LABEL[s].replace(" (proposed)", "") for s in show])
    sel = main[main.method.isin(show)]
    ax.set_xlim(sel[f"{m}_ci_lo"].min() - 0.01, sel[f"{m}_ci_hi"].max() + 0.01)
    ax.set_title(MNAME[m], loc="left"); ax.grid(axis="y", visible=False)
axes[0].invert_yaxis()
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=2, frameon=False)
fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig(os.path.join(FIG, "fig6_baselines.png")); plt.close(fig)

# Fig 7: per-client metrics
fig, axes = plt.subplots(2, 1, figsize=(PW, 5.6), sharey=True)
for ax, pname, title in [(axes[0], "IID", "(a) IID"), (axes[1], "Non-IID (α = 0.5)", "(b) Non-IID (α = 0.5)")]:
    d = pcd[pcd.partition == pname]; K = len(d); w = 0.16
    for j, m in enumerate(METRICS):
        ax.bar(np.arange(K) + (j - 2) * w, d[f"{m}_mean"], yerr=d[f"{m}_sd"], width=w - 0.02, color=C[j],
               label=MNAME[m], capsize=2, error_kw=dict(ecolor=INK2, lw=1))
    ax.set_xticks(np.arange(K), [f"Client {i}" for i in range(1, K + 1)])
    ax.set_ylim(0, 1.15); ax.set_title(title, loc="left"); ax.set_ylabel("Score (local test)"); ax.grid(axis="x", visible=False)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=5, frameon=False)
fig.tight_layout(rect=(0, 0.05, 1, 1)); fig.savefig(os.path.join(FIG, "fig7_per_client.png")); plt.close(fig)

# Fig 8: ROC (seed 0, IID)
fig, ax = plt.subplots(figsize=(5.4, 5.0))
ax.plot([0, 1], [0, 1], color=INK2, ls="--", lw=1)
ax.plot(roc["global"]["fpr"], roc["global"]["tpr"], color=INK, lw=2.5,
        label=f"Global test, n={piid['runs'][0]['n_global_test']}: AUC {roc['global']['auc']:.3f} [{roc['global']['auc_ci'][0]:.3f}, {roc['global']['auc_ci'][1]:.3f}]")
for k, rc in enumerate(roc["clients"]):
    if rc is None:
        continue
    n = piid["runs"][0]["partition"][k]["n_test"]
    ax.step(rc["fpr"], rc["tpr"], where="post", color=C[k], lw=1.8,
            label=f"Client {k+1}, n={n}: AUC {rc['auc']:.3f} [{rc['auc_ci'][0]:.3f}, {rc['auc_ci'][1]:.3f}]")
ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate"); ax.set_aspect("equal")
ax.legend(loc="lower right", frameon=True, framealpha=0.95, fontsize=8.6, title="AUC [bootstrap 95% CI]", title_fontsize=8.6)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig8_roc.png")); plt.close(fig)

# Fig 9: number of clients (4 panels)
fig, axes = plt.subplots(2, 2, figsize=(PW, 6.6)); axes = axes.ravel()
for part, col, lab in [("iid", C[0], "IID"), ("dirichlet", C[1], "Non-IID (α = 0.5)")]:
    d = ov[(ov.dataset == "pima") & (ov.model == "lr") & (ov.partition == part)].sort_values("K")
    axes[0].plot(d.K, d.local_only_acc_mean, color=col, marker="s", ms=6, ls=":", label=f"{lab}, local-only")
    axes[0].errorbar(d.K, d.fedavg_ckks_acc_mean, yerr=d.fedavg_ckks_acc_sd, color=col, marker="o", ms=6, capsize=3, label=f"{lab}, FedAvg + CKKS")
axes[0].set_xticks([4, 8, 16]); axes[0].set_ylabel("Accuracy"); axes[0].set_title("(a) Pima: test accuracy", loc="left")
d = ov[(ov.dataset == "brfss") & (ov.model == "lr") & (ov.partition == "iid")].sort_values("K")
if len(d):
    axes[1].plot(d.K, d.local_only_auc_mean, color=C[0], marker="s", ms=6, ls=":", label="local-only")
    axes[1].errorbar(d.K, d.fedavg_ckks_auc_mean, yerr=d.fedavg_ckks_auc_sd, color=C[0], marker="o", ms=6, capsize=3, label="FedAvg + CKKS")
    axes[1].set_xticks(sorted(d.K)); axes[1].legend(frameon=False, loc="lower left")
axes[1].set_ylabel("AUC"); axes[1].set_title("(b) BRFSS (IID): test AUC", loc="left")
lrK = ov[ov.model == "lr"].groupby("K").agg(agg_ms=("agg_ms_server", "mean"), up_mb=("uplink_mb_per_round", "mean")).reset_index()
axes[2].plot(lrK.K, lrK.agg_ms, color=C[2], marker="o", ms=6)
axes[3].plot(lrK.K, lrK.up_mb, color=C[6], marker="o", ms=6)
axes[2].set_ylabel("ms"); axes[2].set_title("(c) Server aggregation time per round", loc="left")
axes[3].set_ylabel("MB (all clients)"); axes[3].set_title("(d) Uplink ciphertext volume per round", loc="left")
for ax in axes[2:]:
    ax.set_xticks([4, 8, 16, 32, 48, 64])
for ax in axes:
    ax.set_xlabel("Number of clients K")
h0, l0 = axes[0].get_legend_handles_labels()
fig.legend(h0, l0, loc="lower center", ncol=2, frameon=False, fontsize=9.5, title="Panel (a)", title_fontsize=9.5)
fig.tight_layout(rect=(0, 0.1, 1, 1)); fig.savefig(os.path.join(FIG, "fig9_num_clients.png")); plt.close(fig)

if B:
    # Fig 10: BRFSS partitions (seed 0)
    fig, axes = plt.subplots(1, 3, figsize=(PW, 3.0), sharey=True)
    mx = 0
    for ax, p, title in zip(axes, ["iid", "dirichlet", "age"], ["(a) IID", "(b) Non-IID (α = 0.5)", "(c) Age-based"]):
        if lr.get(p):
            mx = max(mx, partition_bars(ax, lr[p]["runs"][0]["partition"], title, scale=1000.0,
                                        labels=("No diabetes", "Diabetes"), show_total=False))
    axes[2].set_xticks(range(1, 5), AGE_LABELS)
    for ax in axes:
        ax.set_ylim(0, mx * 1.2)
    axes[0].set_ylabel("Records per client (thousands)")
    axes[0].legend(loc="upper left", frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig10_brfss_partitions.png")); plt.close(fig)

    # Fig 11: BRFSS AUC and F1 with 95% CI (LR six rows, MLP five rows)
    SHORT = {"centralized_sgd": "centralized", "local_only": "local-only", "fedavg_plain": "FedAvg plaintext",
             "fedavg_ckks": "FedAvg + CKKS", "fedprox_ckks": "FedProx + CKKS", "fedavg_ckks_classweight": "FedAvg + CKKS, class-wt."}
    rows_ = [("LR", m) for m in ["centralized_sgd", "local_only", "fedavg_plain", "fedavg_ckks", "fedprox_ckks", "fedavg_ckks_classweight"]] + \
            [("MLP", m) for m in ["centralized_sgd", "local_only", "fedavg_plain", "fedavg_ckks", "fedavg_ckks_classweight"]]
    fig, axes = plt.subplots(1, 2, figsize=(PW, 4.6), sharey=True)
    for ax, m in zip(axes, ["auc", "f1"]):
        for i, (p, col) in enumerate([("iid", C[0]), ("dirichlet", C[1]), ("age", C[2])]):
            ys, mus, los, his = [], [], [], []
            for j, (model, meth) in enumerate(rows_):
                sel = b9[(b9.model == model) & (b9.partition == PARTS[p]) & (b9.method == meth)]
                if len(sel):
                    s = sel.iloc[0]
                    ys.append(j + (i - 1) * 0.26); mus.append(s[f"{m}_mean"]); los.append(s[f"{m}_ci_lo"]); his.append(s[f"{m}_ci_hi"])
            mus, los, his = map(np.array, (mus, los, his))
            ax.errorbar(mus, ys, xerr=np.vstack([mus - los, his - mus]), fmt="o", ms=5, color=col, ecolor=col,
                        elinewidth=1.5, capsize=2.5, label=PARTS[p])
        ax.axhline(5.5, color=GRID, lw=1.2)
        ax.set_title(f"{MNAME[m]} (mean, 95% CI)", loc="left"); ax.grid(axis="y", visible=False)
    axes[0].set_yticks(range(len(rows_)), [f"{mo}, {SHORT[me]}" for mo, me in rows_])
    axes[0].set_ylim(len(rows_) - 0.5, -0.5)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=3, frameon=False)
    fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig(os.path.join(FIG, "fig11_brfss_baselines.png")); plt.close(fig)

    # Fig 12: BRFSS AUC per round (LR, MLP)
    fig, axes = plt.subplots(1, 2, figsize=(PW, 3.4), sharey=True)
    for ax, D, title in [(axes[0], lr, "(a) LR, FedAvg + CKKS"), (axes[1], mlp, "(b) MLP, FedAvg + CKKS")]:
        for p, col in [("iid", C[0]), ("dirichlet", C[1]), ("age", C[2])]:
            if D.get(p):
                band(ax, D[p], "fedavg_ckks", lambda h: h["global_test"]["auc"], col, PARTS[p])
                ax.axhline(vec(D[p], "local_only", "auc").mean(), color=col, ls=":", lw=1.5)
        ax.set_title(title, loc="left"); ax.set_xlabel("Communication round"); ax.set_xticks([1, 5, 10, 15, 20])
    axes[0].set_ylabel("AUC (global test set)")
    h, l = axes[0].get_legend_handles_labels()
    h.append(matplotlib.lines.Line2D([], [], color=INK2, ls=":", lw=1.8)); l.append("local-only (same colour)")
    fig.legend(h, l, loc="lower center", ncol=4, frameon=False, fontsize=9)
    fig.tight_layout(rect=(0, 0.1, 1, 1)); fig.savefig(os.path.join(FIG, "fig12_brfss_rounds.png")); plt.close(fig)


pd.set_option("display.width", 250, "display.max_columns", 40, "display.max_colwidth", 120)
print(pretty(main).iloc[:, [2, 3, 4, 6, 8, 10, 12]].to_string(index=False))
if B:
    print(pretty(b9).iloc[:, [1, 2, 3, 4, 6, 8, 10, 12]].to_string(index=False))
print(pd.DataFrame(t8).to_string(index=False))
print(pd.DataFrame(t10).to_string(index=False))
print(pd.DataFrame(NUM).to_string(index=False))
