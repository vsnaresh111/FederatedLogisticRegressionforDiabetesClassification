# Original submission (superseded)

These are the files that were posted with the original submission. They are kept unchanged for transparency only and are **not** used for any result in the revised manuscript.

The original notebook (`Project.ipynb`) contains the implementation error described in Section 6.1 of the revised manuscript: the aggregated, decrypted model was never loaded back as the starting point of the next round. It also used separately prepared client files and per-client z-score normalisation. The corrected implementation is `../fl_he.py`; its `fedavg_ckks_no_global_update` method reproduces the original update rule as an ablation.
