# Data

| File | Source | Records | SHA-256 |
|---|---|---|---|
| `diabetes.csv` | Pima Indians Diabetes Database (NIDDK; UCI / Kaggle `uciml/pima-indians-diabetes-database`) | 768 (268 diabetic) | `b78029447fae2743b3218bb2b76ef0d04afe8d7e55ce2faf4d1ec82d8f8ae8ac` |
| `brfss.csv` | CDC BRFSS 2015 Diabetes Health Indicators, Kaggle `alexteboul/diabetes-health-indicators-dataset`, file `diabetes_binary_health_indicators_BRFSS2015.csv` (renamed) | 253,680 (35,346 positive) | `19f367e3e3350768f0c144c5d73ee5b355f67a57eaaa86ca7bd8aec594d8b1d0` |

Both files are included in this repository (both datasets are public; the BRFSS extract is released on Kaggle under CC0). To re-download `brfss.csv` yourself:

```bash
# with the Kaggle CLI (needs a Kaggle API token)
kaggle datasets download -d alexteboul/diabetes-health-indicators-dataset -f diabetes_binary_health_indicators_BRFSS2015.csv -p data --unzip
mv data/diabetes_binary_health_indicators_BRFSS2015.csv data/brfss.csv
sha256sum data/brfss.csv   # should match the table above
```

Both datasets are public and de-identified; use them under the terms of their sources.
