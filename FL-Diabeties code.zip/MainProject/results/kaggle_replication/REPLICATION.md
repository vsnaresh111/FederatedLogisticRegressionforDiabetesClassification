# Independent replication of all experiments

Run A: `results/raw`  
Run B: `results/kaggle_replication/raw`

Library versions - run A: tenseal 0.3.18, numpy 2.5.3, pandas 3.0.5; run B: tenseal 0.3.18, numpy 2.1.3, pandas 2.3.3

Largest difference between the two runs in the **mean over 10 seeds** of each method and metric:

* Logistic regression: accuracy/precision/recall/F1 0.00 percentage points, AUC 3.6e-09
* MLP: accuracy/precision/recall/F1 0.46 percentage points, AUC 4.2e-04
* HE time per round (encrypt + aggregate + decrypt): run B / run A = 1.06-1.37

Logistic-regression results are deterministic; the encrypted MLP differs slightly because CKKS encryption noise (not seedable in TenSEAL) is amplified by non-convex training; timings depend on the hardware.

| Setting | max diff, threshold metrics (pp) | max diff, AUC | HE ms/round, run A | HE ms/round, run B |
|---|---|---|---|---|
| brfss_lr_age_K4 | 0.00 | 2.3e-09 | 17.17 | 21.16 (1.23x) |
| brfss_lr_dirichlet_K4 | 0.00 | 9.7e-10 | 17.38 | 20.75 (1.19x) |
| brfss_lr_iid_K16 | 0.00 | 3.2e-10 | 36.70 | 46.93 (1.28x) |
| brfss_lr_iid_K4 | 0.00 | 9.7e-10 | 19.76 | 20.90 (1.06x) |
| brfss_lr_iid_K64 | 0.00 | 3.6e-09 | 117.98 | 152.62 (1.29x) |
| brfss_mlp_age_K4 | 0.05 | 2.6e-06 | 16.84 | 20.98 (1.25x) |
| brfss_mlp_dirichlet_K4 | 0.46 | 4.2e-04 | 17.11 | 20.80 (1.22x) |
| brfss_mlp_iid_K4 | 0.02 | 6.9e-06 | 16.54 | 21.80 (1.32x) |
| pima_lr_dirichlet_K16 | 0.00 | 0.0e+00 | 42.09 | 54.42 (1.29x) |
| pima_lr_dirichlet_K4 | 0.00 | 0.0e+00 | 21.42 | 26.15 (1.22x) |
| pima_lr_dirichlet_K8 | 0.00 | 0.0e+00 | 25.24 | 34.49 (1.37x) |
| pima_lr_iid_K16 | 0.00 | 0.0e+00 | 42.75 | 52.52 (1.23x) |
| pima_lr_iid_K4 | 0.00 | 0.0e+00 | 21.16 | 25.45 (1.20x) |
| pima_lr_iid_K8 | 0.00 | 0.0e+00 | 26.52 | 35.38 (1.33x) |
| pima_mlp_dirichlet_K4 | 0.00 | 0.0e+00 | 20.12 | 24.67 (1.23x) |
| pima_mlp_iid_K4 | 0.00 | 0.0e+00 | 19.62 | 24.00 (1.22x) |
