"""
Privacy-preserving federated learning with CKKS homomorphic encryption for
diabetes classification (Pima Indians Diabetes Database and CDC BRFSS 2015).

Code accompanying the manuscript
"Enhancing Privacy in Distributed Healthcare Analytics: Federated Logistic
Regression for Diabetes Classification".

One script covers both datasets (--dataset pima|brfss) and both model families
(--model lr|mlp). Every experiment of the manuscript is one call of this script;
run_all.sh lists them all. Raw per-seed results are written as JSON and turned
into the tables and figures of the manuscript by analyze.py.

Protocol (Sections 4-5 of the manuscript)
  * A stratified 20 % global test set is held out before partitioning; the rest
    is split into K clients (IID stratified, non-IID Dirichlet label skew, or -
    BRFSS only - age-based). Each client keeps a stratified 20 % local test split.
  * Federated preprocessing under CKKS: Pima zeros in Glucose, BloodPressure,
    SkinThickness, Insulin and BMI are treated as missing and imputed with the
    sample-size-weighted mean of the clients' local medians (Eq. 11); z-score
    normalisation uses the global mean/SD from encrypted sums and sums of
    squares (Eq. 12). BRFSS has no missing values, so only Eq. 12 is applied.
  * Local model: logistic regression (Eq. 5) or a one-hidden-layer ReLU MLP
    (Eq. 8), trained with mini-batch SGD on binary cross-entropy, PyTorch-default
    initialisation. All parameters are packed into ONE CKKS vector per client.
  * The server holds only a PUBLIC CKKS context (secret key removed) and computes
    the sample-size-weighted FedAvg of the ciphertexts (Eq. 10); clients decrypt
    the aggregate and use it as the starting point of the next round.
  * Baselines/ablations: centralised (SGD and unpenalised L-BFGS), local-only,
    plaintext FedAvg, FedProx (CKKS), unweighted FedAvg (CKKS), class-weighted
    FedAvg (CKKS) and the "original update rule" (no global update, unweighted).

Bug fixed relative to the originally posted notebook (Project.ipynb): the
aggregated, decrypted global model is now loaded back as the starting point of
the next round (in the original code every round restarted from the same
initialisation, which is why the per-round metrics were flat).
"""
from __future__ import annotations

import argparse
import json
import os
import time
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd
import tenseal as ts
from sklearn.linear_model import LogisticRegression as SkLR
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score, roc_auc_score, roc_curve,
                             confusion_matrix)
from sklearn.model_selection import train_test_split

# --------------------------------------------------------------------------
# Dataset definitions
# --------------------------------------------------------------------------
DATASETS = {
    "pima": dict(
        features=["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
                  "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"],
        zero_as_missing=["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"],
        target="Outcome",
        defaults=dict(local_epochs=16, batch_size=16, lr=0.01, hidden=16, n_boot=2000),
    ),
    "brfss": dict(
        features=["HighBP", "HighChol", "CholCheck", "BMI", "Smoker", "Stroke",
                  "HeartDiseaseorAttack", "PhysActivity", "Fruits", "Veggies",
                  "HvyAlcoholConsump", "AnyHealthcare", "NoDocbcCost", "GenHlth",
                  "MentHlth", "PhysHlth", "DiffWalk", "Sex", "Age", "Education", "Income"],
        zero_as_missing=[],          # 0 is a valid answer in BRFSS; no missing values
        target="Diabetes_binary",
        defaults=dict(local_epochs=2, batch_size=128, lr=0.05, hidden=32, n_boot=200),
    ),
}

# Set by set_dataset(); module-level so that all helpers see the active dataset.
FEATURES: list = DATASETS["pima"]["features"]
ZERO_AS_MISSING: list = DATASETS["pima"]["zero_as_missing"]
TARGET: str = DATASETS["pima"]["target"]
HIDDEN = 0   # 0 = logistic regression; >0 = one-hidden-layer ReLU MLP (set in run_seed)

# BRFSS "_AGEG5YR" codes: 1 = 18-24, 2 = 25-29, 3 = 30-34, 4 = 35-39, 5 = 40-44,
# 6 = 45-49, 7 = 50-54, 8 = 55-59, 9 = 60-64, 10 = 65-69, 11 = 70-74, 12 = 75-79, 13 = 80+.
# Age-based clients (Section 5.2): 18-39 (codes 1-4), 40-54 (5-7), 55-69 (8-10), 70+ (11-13).
AGE_BIN_EDGES = [5, 8, 11]
AGE_GROUPS = ["18-39", "40-54", "55-69", "70+"]


def set_dataset(name: str):
    global FEATURES, ZERO_AS_MISSING, TARGET
    d = DATASETS[name]
    FEATURES, ZERO_AS_MISSING, TARGET = d["features"], d["zero_as_missing"], d["target"]


# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
@dataclass
class Config:
    dataset: str = "pima"
    data_path: str = "data/diabetes.csv"
    n_clients: int = 4
    partition: str = "iid"            # "iid" | "dirichlet" | "age" (BRFSS only)
    alpha: float = 0.5                # Dirichlet concentration (non-IID)
    rounds: int = 20
    local_epochs: int = 16
    batch_size: int = 16
    lr: float = 0.01
    model: str = "lr"                 # "lr" | "mlp"
    hidden: int = 16                  # MLP hidden units (Pima 16 -> 161 params, BRFSS 32 -> 737)
    global_test_size: float = 0.2
    local_test_size: float = 0.2
    min_client_size: int = 20
    min_per_class: int = 4
    fedprox_mu: float = 0.01
    max_rows: int = 0                 # 0 = all rows (smoke tests only use >0)
    n_boot: int = 2000                # bootstrap resamples for the AUC CI of the ROC curves
    # CKKS
    poly_modulus_degree: int = 8192
    coeff_mod_bit_sizes: tuple = (60, 40, 40, 60)
    global_scale_bits: int = 40


# --------------------------------------------------------------------------
# Data handling
# --------------------------------------------------------------------------
def load_data(cfg: Config, seed: int) -> pd.DataFrame:
    df = pd.read_csv(cfg.data_path)
    missing = [c for c in FEATURES + [TARGET] if c not in df.columns]
    assert not missing, f"missing columns {missing}; found {list(df.columns)}"
    if cfg.dataset == "pima":
        assert list(df.columns) == FEATURES + [TARGET], df.columns
        return df
    df = df[FEATURES + [TARGET]].copy()
    df[TARGET] = df[TARGET].astype(int)
    n = cfg.max_rows
    if n and n < len(df):          # stratified subsample (smoke tests only; not used in the manuscript)
        parts = [g.sample(n=int(round(n * len(g) / len(df))), random_state=seed)
                 for _, g in df.groupby(TARGET)]
        df = pd.concat(parts).sample(frac=1.0, random_state=seed).reset_index(drop=True)
    return df


def to_missing(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for c in ZERO_AS_MISSING:
        df[c] = df[c].replace(0, np.nan)
    return df


def partition_clients(df: pd.DataFrame, cfg: Config, rng: np.random.Generator):
    """Return list of index arrays (into df) for each client."""
    y = df[TARGET].values
    idx_by_class = {c: np.where(y == c)[0] for c in (0, 1)}
    K = cfg.n_clients
    if cfg.partition == "iid":
        parts = [[] for _ in range(K)]
        for c, idx in idx_by_class.items():
            idx = rng.permutation(idx)
            for k, chunk in enumerate(np.array_split(idx, K)):
                parts[k].extend(chunk.tolist())
        return [np.array(sorted(p)) for p in parts]
    if cfg.partition == "age":
        assert cfg.dataset == "brfss" and K == 4, "age-based partition is defined for BRFSS with K=4"
        grp = np.digitize(df["Age"].values, AGE_BIN_EDGES)
        return [np.where(grp == k)[0] for k in range(4)]
    if cfg.partition == "dirichlet":
        for _attempt in range(10000):
            parts = [[] for _ in range(K)]
            for c, idx in idx_by_class.items():
                idx = rng.permutation(idx)
                p = rng.dirichlet(np.full(K, cfg.alpha))
                cuts = (np.cumsum(p) * len(idx)).astype(int)[:-1]
                for k, chunk in enumerate(np.split(idx, cuts)):
                    parts[k].extend(chunk.tolist())
            ok = all(len(p) >= cfg.min_client_size and
                     min((y[p] == 0).sum(), (y[p] == 1).sum()) >= cfg.min_per_class
                     for p in parts)
            if ok:
                return [np.array(sorted(p)) for p in parts]
        raise RuntimeError("Could not draw a Dirichlet partition satisfying constraints")
    raise ValueError(cfg.partition)


def local_split(df_k: pd.DataFrame, cfg: Config, seed: int):
    y = df_k[TARGET].values
    strat = y if min(np.bincount(y, minlength=2)) >= 2 else None
    tr, te = train_test_split(df_k, test_size=cfg.local_test_size,
                              random_state=seed, stratify=strat)
    return tr, te


# --------------------------------------------------------------------------
# CKKS helpers (key holder = clients, server = public context only)
# --------------------------------------------------------------------------
class CKKS:
    def __init__(self, cfg: Config):
        t0 = time.perf_counter()
        ctx = ts.context(ts.SCHEME_TYPE.CKKS,
                         poly_modulus_degree=cfg.poly_modulus_degree,
                         coeff_mod_bit_sizes=list(cfg.coeff_mod_bit_sizes),
                         n_threads=1)                  # single-threaded timings
        ctx.global_scale = 2 ** cfg.global_scale_bits
        self.keygen_time = time.perf_counter() - t0
        self.client_ctx = ctx                         # holds secret key (shared by clients)
        pub = ctx.copy()
        pub.make_context_public()                     # drops the secret key
        self.public_ctx_bytes = pub.serialize()
        self.server_ctx = ts.context_from(self.public_ctx_bytes)
        assert not self.server_ctx.has_secret_key()
        self.public_ctx_size = len(self.public_ctx_bytes)

    # client side
    def encrypt(self, vec: np.ndarray) -> bytes:
        return ts.ckks_vector(self.client_ctx, vec.tolist()).serialize()

    def decrypt(self, blob: bytes) -> np.ndarray:
        return np.array(ts.ckks_vector_from(self.client_ctx, blob).decrypt())

    # server side: weighted sum of ciphertexts, without the secret key
    def aggregate(self, blobs: list[bytes], weights: list[float]) -> bytes:
        acc = None
        for blob, w in zip(blobs, weights):
            v = ts.ckks_vector_from(self.server_ctx, blob)
            v = v * float(w)
            acc = v if acc is None else acc + v
        return acc.serialize()


# --------------------------------------------------------------------------
# Federated preprocessing (median imputation + z-score) under CKKS
# --------------------------------------------------------------------------
def federated_preprocessing(client_trains, he: CKKS | None):
    n = np.array([len(d) for d in client_trains], dtype=float)
    # (a) federated median for missing-value imputation (weighted mean of local medians, Eq. 11)
    # A client whose column is entirely missing contributes zero weight for it.
    meds = [d[ZERO_AS_MISSING].median(skipna=True).values for d in client_trains]
    num = [nk * np.nan_to_num(m, nan=0.0) for nk, m in zip(n, meds)]
    den = [nk * (~np.isnan(m)).astype(float) for nk, m in zip(n, meds)]
    if he is None or not ZERO_AS_MISSING:
        g_med = np.sum(num, 0) / np.sum(den, 0)
    else:
        ones = [1.0] * len(num)
        g_med = (he.decrypt(he.aggregate([he.encrypt(v) for v in num], ones)) /
                 he.decrypt(he.aggregate([he.encrypt(v) for v in den], ones)))
    med_map = dict(zip(ZERO_AS_MISSING, g_med))
    imputed = [d.fillna(value=med_map) for d in client_trains]
    # (b) federated mean / std from sums and sums of squares (Eq. 12)
    s1 = [d[FEATURES].values.sum(0) for d in imputed]
    s2 = [(d[FEATURES].values ** 2).sum(0) for d in imputed]
    if he is None:
        S1, S2 = np.sum(s1, 0), np.sum(s2, 0)
    else:
        S1 = he.decrypt(he.aggregate([he.encrypt(v) for v in s1], [1.0] * len(s1)))
        S2 = he.decrypt(he.aggregate([he.encrypt(v) for v in s2], [1.0] * len(s2)))
    N = n.sum()
    mu = S1 / N
    sd = np.sqrt(np.maximum(S2 / N - mu ** 2, 1e-12))
    return med_map, mu, sd


def transform(df: pd.DataFrame, med_map, mu, sd):
    X = df.fillna(value=med_map)[FEATURES].values.astype(float)
    return (X - mu) / sd, df[TARGET].values.astype(float)


# --------------------------------------------------------------------------
# Models (NumPy): logistic regression and one-hidden-layer ReLU MLP
# --------------------------------------------------------------------------
def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def n_params(d: int, h: int = 0) -> int:
    return d + 1 if h == 0 else d * h + 2 * h + 1          # MLP: W1 (d*h), b1 (h), w2 (h), b2 (1)


def init_params(d: int, rng: np.random.Generator, h: int = 0) -> np.ndarray:
    """PyTorch-default uniform init: U(-1/sqrt(fan_in), 1/sqrt(fan_in)) for every layer."""
    if h == 0:
        bound = 1.0 / np.sqrt(d)                       # nn.Linear default
        return rng.uniform(-bound, bound, size=d + 1)  # [w_1..w_d, b]
    b1 = 1.0 / np.sqrt(d)
    b2 = 1.0 / np.sqrt(h)
    return np.concatenate([rng.uniform(-b1, b1, d * h), rng.uniform(-b1, b1, h),
                           rng.uniform(-b2, b2, h), rng.uniform(-b2, b2, 1)])


def _unpack(theta, d, h):
    W1 = theta[:d * h].reshape(d, h)
    b1 = theta[d * h:d * h + h]
    w2 = theta[d * h + h:d * h + 2 * h]
    return W1, b1, w2, theta[-1]


def predict_proba(theta, X):
    if HIDDEN == 0:
        return sigmoid(X @ theta[:-1] + theta[-1])
    W1, b1, w2, b2 = _unpack(theta, X.shape[1], HIDDEN)
    return sigmoid(np.maximum(X @ W1 + b1, 0.0) @ w2 + b2)


def bce(theta, X, y, eps=1e-7):
    p = np.clip(predict_proba(theta, X), eps, 1 - eps)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def local_train(theta0, X, y, cfg: Config, rng, epochs=None, mu_prox=0.0,
                pos_weight=1.0):
    """Mini-batch SGD (no momentum) on (class-weighted) BCE; LR or one-hidden-layer MLP."""
    theta = theta0.copy()
    anchor = theta0.copy()
    n, d = X.shape
    h = HIDDEN
    epochs = cfg.local_epochs if epochs is None else epochs
    for _ in range(epochs):
        order = rng.permutation(n)
        for s in range(0, n, cfg.batch_size):
            b = order[s:s + cfg.batch_size]
            Xb, yb = X[b], y[b]
            m = len(b)
            if h == 0:
                p = sigmoid(Xb @ theta[:-1] + theta[-1])
                r = np.where(yb == 1, pos_weight, 1.0) * (p - yb)
                g = np.empty_like(theta)
                g[:-1] = Xb.T @ r / m
                g[-1] = r.mean()
            else:
                W1, b1, w2, b2 = _unpack(theta, d, h)
                z = Xb @ W1 + b1
                a = np.maximum(z, 0.0)
                p = sigmoid(a @ w2 + b2)
                r = np.where(yb == 1, pos_weight, 1.0) * (p - yb)      # dL/dlogit per sample
                delta = (r[:, None] * w2[None, :]) * (z > 0)           # back-prop through ReLU
                g = np.concatenate([(Xb.T @ delta / m).ravel(), delta.mean(0),
                                    a.T @ r / m, [r.mean()]])
            if mu_prox > 0:
                g += mu_prox * (theta - anchor)                        # FedProx proximal term (Eq. 7)
            theta -= cfg.lr * g
    return theta


def metrics(theta, X, y):
    p = predict_proba(theta, X)
    yhat = (p > 0.5).astype(int)
    out = dict(acc=accuracy_score(y, yhat),
               prec=precision_score(y, yhat, zero_division=0),
               rec=recall_score(y, yhat, zero_division=0),
               f1=f1_score(y, yhat, zero_division=0),
               loss=bce(theta, X, y))
    out["auc"] = roc_auc_score(y, p) if len(np.unique(y)) == 2 else np.nan
    return out


# --------------------------------------------------------------------------
# One complete experiment for one seed
# --------------------------------------------------------------------------
METHODS_ALL = ["centralized_sgd", "centralized_sklearn", "local_only",
               "fedavg_plain", "fedavg_ckks", "fedprox_ckks",
               "fedavg_ckks_unweighted", "fedavg_ckks_classweight",
               "fedavg_ckks_no_global_update"]


def prepare(cfg: Config, seed: int):
    df = to_missing(load_data(cfg, seed))
    rng_split = np.random.default_rng(seed)
    pool, gtest = train_test_split(df, test_size=cfg.global_test_size,
                                   random_state=seed, stratify=df[TARGET])
    pool = pool.reset_index(drop=True)
    parts = partition_clients(pool, cfg, rng_split)
    clients = []
    for k, idx in enumerate(parts):
        tr, te = local_split(pool.iloc[idx], cfg, seed * 100 + k)
        clients.append(dict(train=tr, test=te))
    return pool, gtest, clients


def run_seed(cfg: Config, seed: int, methods=None, record_rounds=True):
    global HIDDEN
    set_dataset(cfg.dataset)
    HIDDEN = cfg.hidden if cfg.model == "mlp" else 0
    methods = methods or METHODS_ALL
    pool, gtest, clients = prepare(cfg, seed)
    K = len(clients)
    he = CKKS(cfg)

    # federated preprocessing (encrypted) and its plaintext reference
    med_map, mu, sd = federated_preprocessing([c["train"] for c in clients], he)
    med_p, mu_p, sd_p = federated_preprocessing([c["train"] for c in clients], None)
    prep_err = float(max(np.max(np.abs(np.array(list(med_map.values())) - np.array(list(med_p.values()))), initial=0.0),
                         np.max(np.abs(mu - mu_p)), np.max(np.abs(sd - sd_p))))
    Xg, yg = transform(gtest, med_map, mu, sd)
    for c in clients:
        c["Xtr"], c["ytr"] = transform(c["train"], med_map, mu, sd)
        c["Xte"], c["yte"] = transform(c["test"], med_map, mu, sd)
    n_k = np.array([len(c["ytr"]) for c in clients], dtype=float)
    w_k = n_k / n_k.sum()

    theta_init = init_params(len(FEATURES), np.random.default_rng(10_000 + seed), HIDDEN)
    total_epochs = cfg.rounds * cfg.local_epochs

    partition_info = [dict(client=k + 1, n_train=int(len(c["ytr"])),
                           n_train_pos=int(c["ytr"].sum()),
                           n_test=int(len(c["yte"])), n_test_pos=int(c["yte"].sum()))
                      for k, c in enumerate(clients)]

    results = dict(seed=seed, partition=partition_info, prep_ckks_abs_err=prep_err,
                   n_global_test=int(len(yg)), n_global_test_pos=int(yg.sum()),
                   ckks=dict(keygen_s=he.keygen_time, public_ctx_bytes=he.public_ctx_size),
                   final={}, rounds={}, per_client_final={}, roc={})

    def record_final(name, theta):
        results["final"][name] = metrics(theta, Xg, yg)
        results["per_client_final"][name] = [metrics(theta, c["Xte"], c["yte"]) for c in clients]

    # ---------- centralised baselines (pooled training data of all clients)
    if "centralized_sgd" in methods or "centralized_sklearn" in methods:
        pooled = pd.concat([c["train"] for c in clients])
        med_c = pooled[ZERO_AS_MISSING].median(skipna=True).to_dict()
        Xc_raw = pooled.fillna(value=med_c)[FEATURES].values.astype(float)
        mu_c, sd_c = Xc_raw.mean(0), Xc_raw.std(0)
        Xc, yc = (Xc_raw - mu_c) / sd_c, pooled[TARGET].values.astype(float)
        Xg_c, _ = transform(gtest, med_c, mu_c, sd_c)
        if "centralized_sgd" in methods:
            th = local_train(theta_init, Xc, yc, cfg, np.random.default_rng(20_000 + seed),
                             epochs=total_epochs)
            results["final"]["centralized_sgd"] = metrics(th, Xg_c, yg)
        if "centralized_sklearn" in methods and HIDDEN == 0:
            sk = SkLR(C=np.inf, max_iter=5000).fit(Xc, yc)   # unpenalized maximum-likelihood optimum
            th = np.r_[sk.coef_.ravel(), sk.intercept_]
            results["final"]["centralized_sklearn"] = metrics(th, Xg_c, yg)

    # ---------- local-only baseline (each client alone, same epoch budget)
    if "local_only" in methods:
        per = []
        for k, c in enumerate(clients):
            th = local_train(theta_init, c["Xtr"], c["ytr"], cfg,
                             np.random.default_rng(30_000 + 100 * seed + k), epochs=total_epochs)
            per.append(dict(global_test=metrics(th, Xg, yg),
                            local_test=metrics(th, c["Xte"], c["yte"])))
        results["local_only_per_client"] = per
        results["final"]["local_only"] = {m: float(np.nanmean([p["global_test"][m] for p in per]))
                                          for m in per[0]["global_test"]}

    # ---------- federated variants
    fl_specs = {
        "fedavg_plain": dict(enc=False, mu=0.0, weighted=True, cw=False, update=True),
        "fedavg_ckks": dict(enc=True, mu=0.0, weighted=True, cw=False, update=True),
        "fedprox_ckks": dict(enc=True, mu=cfg.fedprox_mu, weighted=True, cw=False, update=True),
        "fedavg_ckks_unweighted": dict(enc=True, mu=0.0, weighted=False, cw=False, update=True),
        "fedavg_ckks_classweight": dict(enc=True, mu=0.0, weighted=True, cw=True, update=True),
        "fedavg_ckks_no_global_update": dict(enc=True, mu=0.0, weighted=False, cw=False, update=False),
    }
    for name, sp in fl_specs.items():
        if name not in methods:
            continue
        theta_g = theta_init.copy()
        hist = []
        timing = dict(enc_s=[], agg_s=[], dec_s=[], ct_bytes=[], agg_ct_bytes=[], approx_err=[])
        agg_w = list(w_k) if sp["weighted"] else [1.0 / K] * K
        for r in range(cfg.rounds):
            start = theta_g if sp["update"] else theta_init
            locals_ = []
            for k, c in enumerate(clients):
                pw = ((c["ytr"] == 0).sum() / max((c["ytr"] == 1).sum(), 1)) if sp["cw"] else 1.0
                th = local_train(start, c["Xtr"], c["ytr"], cfg,
                                 np.random.default_rng([seed, r, k]),
                                 mu_prox=sp["mu"], pos_weight=pw)
                locals_.append(th)
            plain_agg = np.sum([w * t for w, t in zip(agg_w, locals_)], axis=0)
            if sp["enc"]:
                t0 = time.perf_counter()
                blobs = [he.encrypt(t) for t in locals_]
                t1 = time.perf_counter()
                agg_blob = he.aggregate(blobs, agg_w)
                t2 = time.perf_counter()
                new_theta = he.decrypt(agg_blob)[: len(theta_g)]
                t3 = time.perf_counter()
                timing["enc_s"].append((t1 - t0) / K)       # per client
                timing["agg_s"].append(t2 - t1)             # server
                timing["dec_s"].append(t3 - t2)             # per client
                timing["ct_bytes"].append(int(np.mean([len(b) for b in blobs])))
                timing["agg_ct_bytes"].append(len(agg_blob))
                timing["approx_err"].append(float(np.max(np.abs(new_theta - plain_agg))))
            else:
                new_theta = plain_agg
            theta_g = new_theta
            if record_rounds:
                gm = metrics(theta_g, Xg, yg)
                train_loss = float(np.sum([w * bce(theta_g, c["Xtr"], c["ytr"])
                                           for w, c in zip(w_k, clients)]))
                cl = [metrics(theta_g, c["Xte"], c["yte"]) for c in clients]
                hist.append(dict(round=r + 1, train_loss=train_loss, global_test=gm,
                                 clients=cl))
        record_final(name, theta_g)
        results["rounds"][name] = hist
        results.setdefault("theta_final", {})[name] = theta_g.tolist()
        if sp["enc"]:
            results.setdefault("timing", {})[name] = {k: (float(np.mean(v)) if v else None)
                                                      for k, v in timing.items()}
            results["timing"][name]["approx_err_max"] = float(np.max(timing["approx_err"]))
        if name == "fedavg_ckks":
            results["roc"]["global"] = _roc(theta_g, Xg, yg, cfg.n_boot)
            results["roc"]["clients"] = [_roc(theta_g, c["Xte"], c["yte"], cfg.n_boot) for c in clients]
            yhat = (predict_proba(theta_g, Xg) > 0.5).astype(int)
            results["confusion_global_fedavg_ckks"] = confusion_matrix(yg, yhat).tolist()

    # ---------- encrypted vs plaintext FedAvg: parameter gap and changed test predictions
    tf = results.get("theta_final", {})
    if "fedavg_plain" in tf and "fedavg_ckks" in tf:
        a, b = np.array(tf["fedavg_plain"]), np.array(tf["fedavg_ckks"])
        results["final_param_gap_ckks_vs_plain"] = float(np.max(np.abs(a - b)))
        results["pred_changes_ckks_vs_plain"] = int(((predict_proba(a, Xg) > 0.5) !=
                                                     (predict_proba(b, Xg) > 0.5)).sum())
        results["auc_gap_ckks_vs_plain"] = float(abs(results["final"]["fedavg_ckks"]["auc"] -
                                                     results["final"]["fedavg_plain"]["auc"]))
    results["n_params"] = int(len(theta_init))
    results["plain_payload_bytes"] = int(len(theta_init) * 8)   # float64 vector
    return results


def _roc(theta, X, y, n_boot=2000, seed=0):
    """ROC curve, AUC and a percentile-bootstrap 95% CI for the AUC."""
    p = predict_proba(theta, X)
    if len(np.unique(y)) < 2:
        return None
    fpr, tpr, _ = roc_curve(y, p)
    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_boot):
        i = rng.integers(0, len(y), len(y))
        if len(np.unique(y[i])) == 2:
            boots.append(roc_auc_score(y[i], p[i]))
    lo, hi = np.percentile(boots, [2.5, 97.5])
    if len(fpr) > 2000:                     # thin very long curves (BRFSS) for storage; AUC uses all points
        keep = np.unique(np.r_[0, np.linspace(0, len(fpr) - 1, 2000).astype(int), len(fpr) - 1])
        fpr, tpr = fpr[keep], tpr[keep]
    return dict(fpr=fpr.tolist(), tpr=tpr.tolist(), auc=float(roc_auc_score(y, p)),
                auc_ci=[float(lo), float(hi)])


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--dataset", default="pima", choices=list(DATASETS))
    ap.add_argument("--data", default=None, help="CSV path (default: data/diabetes.csv or data/brfss.csv)")
    ap.add_argument("--out", default="results/raw")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--clients", type=int, default=4)
    ap.add_argument("--partition", default="iid", choices=["iid", "dirichlet", "age"])
    ap.add_argument("--alpha", type=float, default=0.5)
    ap.add_argument("--methods", default="all")
    ap.add_argument("--tag", default=None)
    ap.add_argument("--min_client_size", type=int, default=20)
    ap.add_argument("--min_per_class", type=int, default=4)
    ap.add_argument("--model", default="lr", choices=["lr", "mlp"])
    ap.add_argument("--hidden", type=int, default=None)
    ap.add_argument("--rounds", type=int, default=20)
    ap.add_argument("--local_epochs", type=int, default=None)
    ap.add_argument("--batch_size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=None)
    ap.add_argument("--max_rows", type=int, default=0)
    a = ap.parse_args()
    dflt = DATASETS[a.dataset]["defaults"]
    pick = lambda v, k: dflt[k] if v is None else v
    cfg = Config(dataset=a.dataset,
                 data_path=a.data or ("data/diabetes.csv" if a.dataset == "pima" else "data/brfss.csv"),
                 n_clients=a.clients, partition=a.partition, alpha=a.alpha, rounds=a.rounds,
                 local_epochs=pick(a.local_epochs, "local_epochs"), batch_size=pick(a.batch_size, "batch_size"),
                 lr=pick(a.lr, "lr"), model=a.model, hidden=pick(a.hidden, "hidden"),
                 min_client_size=a.min_client_size, min_per_class=a.min_per_class,
                 max_rows=a.max_rows, n_boot=dflt["n_boot"])
    methods = METHODS_ALL if a.methods == "all" else a.methods.split(",")
    tag = a.tag or f"{a.dataset}_{a.model}_{a.partition}_K{a.clients}"
    os.makedirs(a.out, exist_ok=True)
    allres = []
    t_start = time.time()
    for s in range(a.seeds):
        t0 = time.time()
        res = run_seed(cfg, s, methods)
        allres.append(res)
        f = res["final"].get("fedavg_ckks", {})
        print(f"[{tag}] seed {s}: FedAvg-CKKS acc={f.get('acc', float('nan')):.4f} "
              f"auc={f.get('auc', float('nan')):.4f}  ({time.time() - t0:.1f}s)", flush=True)
    meta = dict(tenseal=ts.__version__, numpy=np.__version__, pandas=pd.__version__,
                wall_time_s=time.time() - t_start)
    with open(os.path.join(a.out, f"raw_{tag}.json"), "w") as fh:
        json.dump(dict(config=asdict(cfg), methods=methods, meta=meta, runs=allres), fh)


if __name__ == "__main__":
    main()
