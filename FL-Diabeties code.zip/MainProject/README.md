# Federated logistic regression with CKKS homomorphic encryption for diabetes classification

Code, raw results, tables and figures for the manuscript

> **Enhancing Privacy in Distributed Healthcare Analytics: Federated Logistic Regression for Diabetes Classification**
> V. S. Naresh, N. N. S. V. S. S. Rihitha, R. R. Lekha, C. V. V. D. Lakshmi, L. S. Yaramolu, D. S. P. M. Reddy

Every number, table and figure in the revised manuscript is produced by the code in this repository from the raw result files in `results/raw/`.

## What is in the repository

| Path | Content |
|---|---|
| `fl_he.py` | The complete experiment: data partitioning, encrypted federated preprocessing, LR/MLP training, CKKS-encrypted FedAvg (TenSEAL), all baselines and ablations. One call = one setting × N seeds. |
| `analyze.py` | Turns `results/raw/*.json` into Tables 2–10, Figs. 3–12 and `results/tables/manuscript_numbers.csv` (every other number quoted in the text). |
| `run_all.sh` | Runs every experiment of the manuscript, then `analyze.py`. |
| `notebooks/fl_ckks_diabetes_kaggle.ipynb` | Self-contained Kaggle notebook (installs TenSEAL, finds both datasets under /kaggle/input, runs every experiment, builds all tables and figures). |
| `results/raw/` | Raw per-seed results (JSON) of the runs reported in the manuscript. |
| `results/tables/`, `results/figures/` | Generated tables (CSV) and figures (PNG, 300 dpi). |
| `results/logs/` | Console logs of the reported run. |
| `results/kaggle_replication/` | Independent re-run of the complete pipeline on Kaggle (raw results, tables, logs, executed notebook) and `REPLICATION.md`, the comparison with the reported run. |
| `compare_runs.py` | Compares two complete runs and writes the replication report. |
| `data/` | `diabetes.csv` (Pima) and `brfss.csv` (BRFSS 2015), with sources and checksums in `data/README.md`. |
| `original_submission/` | The originally posted notebook and files, kept for transparency (see "Correction" below). |

## Quick start

```bash
pip install -r requirements.txt            # TenSEAL 0.3.18 (exact versions used: see requirements.txt)
bash run_all.sh                            # full protocol, 10 seeds (~3 h on 2 vCPUs)
QUICK=1 bash run_all.sh                    # 2-seed smoke test (not citable)
python analyze.py results                  # re-create tables/figures from the shipped raw results only
```

A single setting, e.g. encrypted FedAvg on Pima with 4 IID clients:

```bash
python fl_he.py --dataset pima --model lr --partition iid --clients 4 --seeds 10
```

Options: `--dataset pima|brfss`, `--model lr|mlp`, `--partition iid|dirichlet|age` (age: BRFSS only), `--clients K`, `--alpha`, `--methods` (comma-separated, default all), `--seeds`, `--rounds`, `--local_epochs`, `--batch_size`, `--lr`, `--hidden`.

## Experimental protocol (Sections 4–5 of the manuscript)

* **Splits.** For every seed (0–9) a stratified 20 % global test set is held out first (Pima 154 records, BRFSS 50,736); the remaining records are partitioned into K clients, each of which keeps a stratified 20 % local test split.
* **Partitions.** IID (stratified equal split); non-IID label skew with Dirichlet(α = 0.5) class proportions (accepted only if every client has ≥ 20 records and ≥ 4 per class; Pima K = 8: 15/2, K = 16: 10/1); age-based (BRFSS, K = 4): 18–39, 40–54, 55–69 and ≥ 70 years (BRFSS age codes 1–4, 5–7, 8–10, 11–13).
* **Encrypted federated preprocessing.** Pima zeros in Glucose, BloodPressure, SkinThickness, Insulin and BMI are treated as missing and imputed with the sample-size-weighted mean of the clients' local medians; z-scoring uses the global mean/SD from encrypted per-client sums and sums of squares. BRFSS has no missing values (z-scoring only).
* **Models.** Logistic regression (9 / 22 parameters) and a one-hidden-layer ReLU MLP (Pima h = 16 → 161 parameters; BRFSS h = 32 → 737 parameters); mini-batch SGD on binary cross-entropy, no momentum, PyTorch-default initialisation.
* **Hyperparameters.** R = 20 rounds. Pima: E = 16 local epochs, B = 16, η = 0.01. BRFSS: E = 2, B = 128, η = 0.05. FedProx μ = 0.01. Class-weighted variant: positive-class weight n_k,0 / n_k,1.
* **CKKS (TenSEAL 0.3.18).** N = 8192 (4096 slots), coefficient modulus [60, 40, 40, 60] bits, scale 2^40 (≈128-bit security), single-threaded. All parameters of a client are packed into one ciphertext. The server receives a public context without the secret key (`has_secret_key() == False`) and computes the sample-size-weighted sum of ciphertexts; clients decrypt the aggregate and start the next round from it.
* **Methods.** `centralized_sgd`, `centralized_sklearn` (unpenalised L-BFGS, LR only), `local_only`, `fedavg_plain`, `fedavg_ckks` (proposed), `fedprox_ckks`, `fedavg_ckks_unweighted`, `fedavg_ckks_classweight`, `fedavg_ckks_no_global_update` (replica of the original update rule).
* **Reported run.** 2-vCPU Intel Xeon 2.1 GHz VM, Python 3.13, the Pima and BRFSS queues running as two concurrent single-threaded processes (exactly as `run_all.sh` does); total wall time about 3 h.

## What to expect when you re-run

An independent re-run on Kaggle (Python 3.13.15, NumPy 2.1.3, pandas 2.3.3; see `results/kaggle_replication/REPLICATION.md`) reproduced every logistic-regression result exactly (identical accuracy, precision, recall and F1 in every seed; AUC differences below 10⁻⁸), the mean metrics of the encrypted MLP to within 0.46 percentage points and 0.0005 AUC, with HE timings 6–37 % higher on that hardware.


* **Plaintext methods** (centralized, local-only, plaintext FedAvg) are fully deterministic for a given seed.
* **Encrypted logistic regression** reproduces the reported metrics exactly (identical predictions); the parameters differ from run to run only by CKKS encryption noise (~10⁻⁷), because TenSEAL's encryption randomness cannot be seeded.
* **Encrypted MLP**: the same ~10⁻⁷ noise is amplified by non-convex SGD, so encrypted-MLP metrics can differ from the reported ones in the third or fourth decimal of the AUC (Section 6.9 of the manuscript).
* **Timings** depend on the machine and on load and typically vary by about ±15 % between runs.

## Mapping to the manuscript

| Manuscript | File |
|---|---|
| Table 2 / Table 3 | `results/tables/table2_pima_features.csv`, `table3_brfss_features.csv` |
| Table 4, Figs. 3, 10 | `table4_partitions_seed0.csv`, `fig3_pima_partitions.png`, `fig10_brfss_partitions.png` |
| Table 6, Figs. 4–6 | `table6_pima_results(_pretty).csv`, `fig4_loss.png`, `fig5_metrics_rounds.png`, `fig6_baselines.png` |
| Section 6.4, Figs. 7–8 | `table_per_client.csv`, `fig7_per_client.png`, `fig8_roc.png` |
| Table 7 | `table7_pima_overhead.csv` |
| Table 8, Fig. 9 | `table8_num_clients.csv`, `fig9_num_clients.png` |
| Table 9, Figs. 11–12 | `table9_brfss_results(_pretty).csv`, `fig11_brfss_baselines.png`, `fig12_brfss_rounds.png` |
| Table 10 | `table10_lr_vs_mlp.csv` |
| Wilcoxon tests | `table_paired_tests.csv` |
| All other numbers in the text | `manuscript_numbers.csv`, `table_overhead_all.csv` |

## Correction relative to the original submission

The notebook posted with the original submission (`original_submission/Project.ipynb`) decrypted the aggregated model for evaluation but never loaded it back as the starting point of the next round, so every round restarted from the same initialisation; it also used separately prepared client files and per-client normalisation. This repository contains the corrected implementation; the `fedavg_ckks_no_global_update` method reproduces the original update rule as an ablation.

## Data

* Pima Indians Diabetes Database (768 records): Smith et al. (1988); UCI / Kaggle `uciml/pima-indians-diabetes-database`. Included as `data/diabetes.csv`.
* CDC BRFSS 2015 Diabetes Health Indicators (253,680 records): Kaggle `alexteboul/diabetes-health-indicators-dataset`, file `diabetes_binary_health_indicators_BRFSS2015.csv`. See `data/README.md`.

SHA-256 of the files used: see `data/README.md`.
