"""
Compare two complete runs of the pipeline (e.g. the reported run and an independent re-run)
and write a Markdown replication report.

    python compare_runs.py results/raw results/kaggle_replication/raw > results/kaggle_replication/REPLICATION.md
"""
import glob
import json
import os
import sys

import numpy as np

A, B = sys.argv[1], sys.argv[2]
MET = ["acc", "prec", "rec", "f1", "auc"]
rows, lr_thr, lr_auc, mlp_thr, mlp_auc, ratios = [], 0.0, 0.0, 0.0, 0.0, []
meta = {}
for pa in sorted(glob.glob(os.path.join(A, "raw_*.json"))):
    name = os.path.basename(pa)
    pb = os.path.join(B, name)
    if not os.path.exists(pb):
        rows.append(f"| {name[4:-5]} | missing in second run | | | |")
        continue
    a, b = json.load(open(pa)), json.load(open(pb))
    meta = (a.get("meta", {}), b.get("meta", {}))
    model = a["config"]["model"]
    d_thr = d_auc = 0.0
    for m in a["runs"][0]["final"]:
        for k in MET:
            va = np.mean([r["final"][m][k] for r in a["runs"]])
            vb = np.mean([r["final"][m][k] for r in b["runs"]])
            if k == "auc":
                d_auc = max(d_auc, abs(va - vb))
            else:
                d_thr = max(d_thr, abs(va - vb))
    he = lambda run: np.mean([t["enc_s"] + t["agg_s"] + t["dec_s"] for t in (r["timing"]["fedavg_ckks"] for r in run["runs"])])
    ratio = he(b) / he(a)
    ratios.append(ratio)
    if model == "lr":
        lr_thr, lr_auc = max(lr_thr, d_thr), max(lr_auc, d_auc)
    else:
        mlp_thr, mlp_auc = max(mlp_thr, d_thr), max(mlp_auc, d_auc)
    rows.append(f"| {name[4:-5]} | {100*d_thr:.2f} | {d_auc:.1e} | {1e3*he(a):.2f} | {1e3*he(b):.2f} ({ratio:.2f}x) |")

print("# Independent replication of all experiments\n")
print(f"Run A: `{A}`  \nRun B: `{B}`\n")
if meta:
    v = lambda d: ", ".join(f"{k} {d[k]}" for k in ("tenseal", "numpy", "pandas") if k in d)
    print(f"Library versions - run A: {v(meta[0])}; run B: {v(meta[1])}\n")
print("Largest difference between the two runs in the **mean over 10 seeds** of each method and metric:\n")
print(f"* Logistic regression: accuracy/precision/recall/F1 {100*lr_thr:.2f} percentage points, AUC {lr_auc:.1e}")
print(f"* MLP: accuracy/precision/recall/F1 {100*mlp_thr:.2f} percentage points, AUC {mlp_auc:.1e}")
print(f"* HE time per round (encrypt + aggregate + decrypt): run B / run A = {min(ratios):.2f}-{max(ratios):.2f}\n")
print("Logistic-regression results are deterministic; the encrypted MLP differs slightly because CKKS encryption noise "
      "(not seedable in TenSEAL) is amplified by non-convex training; timings depend on the hardware.\n")
print("| Setting | max diff, threshold metrics (pp) | max diff, AUC | HE ms/round, run A | HE ms/round, run B |")
print("|---|---|---|---|---|")
print("\n".join(rows))
