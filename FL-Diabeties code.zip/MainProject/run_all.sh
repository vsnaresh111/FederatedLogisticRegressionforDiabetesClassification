#!/usr/bin/env bash
# Reproduces every experiment, table and figure of the manuscript.
#
#   bash run_all.sh            # full protocol: 10 seeds (about 3-4 h on 2 vCPUs)
#   QUICK=1 bash run_all.sh    # 2-seed smoke test (results NOT citable)
#
# The Pima and BRFSS experiments run as two concurrent single-threaded queues,
# as in the manuscript (Section 5.4). Data are expected in data/diabetes.csv and
# data/brfss.csv (see data/README.md). Raw results -> results/raw, then
# analyze.py writes results/tables and results/figures.
set -euo pipefail
cd "$(dirname "$0")"

SEEDS=10
if [[ "${QUICK:-0}" == "1" ]]; then SEEDS=2; fi
OUT=results/raw
mkdir -p "$OUT" results/logs

ALL=all
SC=centralized_sgd,local_only,fedavg_plain,fedavg_ckks                          # scalability runs
M4=centralized_sgd,centralized_sklearn,local_only,fedavg_plain,fedavg_ckks,fedavg_ckks_classweight,fedprox_ckks
MM=centralized_sgd,local_only,fedavg_plain,fedavg_ckks,fedavg_ckks_classweight   # MLP runs

pima() { "${PYTHON:-python}" fl_he.py --dataset pima --data data/diabetes.csv --out "$OUT" --seeds "$SEEDS" "$@"; }
brfss() { "${PYTHON:-python}" fl_he.py --dataset brfss --data data/brfss.csv --out "$OUT" --seeds "$SEEDS" "$@"; }

pima_queue() {
  # Logistic regression, K = 4 (Tables 4, 6, 7; Figs. 3-8)
  pima --model lr --partition iid       --clients 4 --methods $ALL
  pima --model lr --partition dirichlet --clients 4 --alpha 0.5 --methods $ALL
  # Number of clients (Table 8, Fig. 9)
  pima --model lr --partition iid       --clients 8  --methods $SC
  pima --model lr --partition iid       --clients 16 --methods $SC
  pima --model lr --partition dirichlet --clients 8  --methods $SC --min_client_size 15 --min_per_class 2
  pima --model lr --partition dirichlet --clients 16 --methods $SC --min_client_size 10 --min_per_class 1
  # MLP, 16 hidden units = 161 parameters (Section 6.9, Table 10)
  pima --model mlp --partition iid       --clients 4 --methods $MM
  pima --model mlp --partition dirichlet --clients 4 --alpha 0.5 --methods $MM
}

brfss_queue() {
  # Logistic regression, K = 4, three partitions (Table 9, Figs. 10-12)
  brfss --model lr --partition iid       --clients 4 --methods $M4
  brfss --model lr --partition dirichlet --clients 4 --alpha 0.5 --methods $M4
  brfss --model lr --partition age       --clients 4 --methods $M4
  # Number of clients (Table 8, Fig. 9)
  brfss --model lr --partition iid --clients 16 --methods $SC
  brfss --model lr --partition iid --clients 64 --methods $SC
  # MLP, 32 hidden units = 737 parameters (Table 9, Table 10, Fig. 12b)
  brfss --model mlp --partition iid       --clients 4 --methods $MM
  brfss --model mlp --partition dirichlet --clients 4 --alpha 0.5 --methods $MM
  brfss --model mlp --partition age       --clients 4 --methods $MM
}

pima_queue  > results/logs/pima.log  2>&1 &
brfss_queue > results/logs/brfss.log 2>&1 &
wait
"${PYTHON:-python}" analyze.py results > results/logs/analyze.log 2>&1
echo "Done. Tables: results/tables, figures: results/figures, in-text numbers: results/tables/manuscript_numbers.csv"
